package com.example.android.softkeyboard.sqlitehelper;

import java.util.ArrayList;

import com.example.android.softkeyboard.datamodel.UserSelectedWord;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class WordDAO {

    public static final String TAG = "WordDAO";
        
    private static final String dbName = "user.db";
    public static final int dbVersion = 1;
    
    private static final String UserSelected = "UserSelected";
    
    public static class TABLE_COLUMNS
    {
        public static final String ID = "_id";
        public static final String COMPOSING = "composing";
        public static final String COMPOSING_NORMAL = "composingNormal";
        public static final String KEY_TYPE = "type";
    }
    private static final String CREATE_TABLE = "create table if not exists " + UserSelected + "(" +
        TABLE_COLUMNS.ID + " INTEGER PRIMARY KEY, " +
        TABLE_COLUMNS.COMPOSING + " TEXT, " +
        TABLE_COLUMNS.COMPOSING_NORMAL + " TEXT, " +
        TABLE_COLUMNS.KEY_TYPE + " INTEGER);";

    
    private OpenHelper opener;
    private SQLiteDatabase db;
    
    private Context context;
    
    public WordDAO(Context context) throws Exception
    {
        this.context = context;
        this.opener = new OpenHelper(context, dbName, null, dbVersion);
        
        try
        {
            db = opener.getWritableDatabase();
        }
        catch(Exception e)
        {
            throw e;
        }
    }
    
    
    public void reset()
    {
        String sql = "delete from " + UserSelected;
        db.execSQL(sql);
    }

    private class OpenHelper extends SQLiteOpenHelper 
    {
        public OpenHelper(Context context, String name, CursorFactory factory, int version)
        {
            super(context, name, null, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
        }
        
    }
    
    /**
     * Insert a row to database
     */
    public void insertData(UserSelectedWord selectedWord) {
        ContentValues values = new ContentValues();
        values.put(TABLE_COLUMNS.COMPOSING, selectedWord.getComposing());
        values.put(TABLE_COLUMNS.COMPOSING_NORMAL, selectedWord.getComposingNormal());
        values.put(TABLE_COLUMNS.KEY_TYPE, selectedWord.getTypeOfWord());
        String sql = "select * from " + UserSelected + " where composing = ?;";
        Cursor cursor = db.rawQuery(sql, new String[] { selectedWord.getComposing() });
        
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            db.update(UserSelected, values, TABLE_COLUMNS.ID + "=" + id, null);
        } else {   
            db.insert(UserSelected, null, values);
            
        }
        cursor.close();
    }
    
    /**
     * Get all data
     */
    public ArrayList<UserSelectedWord> getAllData(){
        ArrayList<UserSelectedWord> ct = new ArrayList<UserSelectedWord>();
        
        Cursor cursor = null;
        cursor = db.query(UserSelected, null, null, null, null, null,null);
        if(cursor == null) {
            return null;
        }
        
        cursor.moveToFirst();
        int rowCount = cursor.getCount();
        
        for(int i = 0; i < rowCount; i++){
            String composing = cursor.getString(cursor.getColumnIndex(TABLE_COLUMNS.COMPOSING));
            String composingNormal = cursor.getString(cursor.getColumnIndex(TABLE_COLUMNS.COMPOSING_NORMAL));
            int type = cursor.getInt(cursor.getColumnIndex(TABLE_COLUMNS.KEY_TYPE));
            UserSelectedWord obj = new UserSelectedWord(composing, composingNormal, type);      
            ct.add(obj);
            cursor.moveToNext();
        }
        cursor.close();
        return ct;
    }
}