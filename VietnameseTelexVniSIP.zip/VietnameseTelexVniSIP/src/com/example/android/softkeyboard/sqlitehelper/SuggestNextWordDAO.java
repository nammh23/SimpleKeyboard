package com.example.android.softkeyboard.sqlitehelper;


import java.util.ArrayList;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class SuggestNextWordDAO {
    
    public static final String TAG = "SuggestNextWordDAO";
    
    private static final String dbName = "paragraph.db";
    public static final int dbVersion = 1;
    
    private static final String Suggest = "suggest";
    
    public static class TABLE_COLUMNS
    {
        public static final String ID = "_id";
        public static final String PARAGRAPH = "paragraph";
    }
    
    private static final String CREATE_TABLE = "create table if not exists " + Suggest + "(" +
        TABLE_COLUMNS.ID + " INTEGER PRIMARY KEY, " +
        TABLE_COLUMNS.PARAGRAPH + " TEXT);";

    
    private OpenHelper opener;
    private SQLiteDatabase db;
    
    private Context context;
    
    public SuggestNextWordDAO(Context context) throws Exception
    {
        this.context = context;
        this.opener = new OpenHelper(context, dbName, null, dbVersion);
        
        try
        {
            db = opener.getWritableDatabase();
        }
        catch(Exception e)
        {
            throw e;
        }
    }
    
    public void reset()
    {
        String sql = "delete from " + Suggest;
        db.execSQL(sql);
    }
    
    private class OpenHelper extends SQLiteOpenHelper 
    {
        public OpenHelper(Context context, String name, CursorFactory factory, int version)
        {
            super(context, name, null, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
        }
        
    }
    
      /**
      * Insert a row to database
      */
     public void insertData(String paragraph, int id) {
         ContentValues values = new ContentValues();
         values.put(TABLE_COLUMNS.PARAGRAPH, paragraph);
         if (id != -1) {
             db.update(Suggest, values, TABLE_COLUMNS.ID + "=" + id, null);
         } else {   
             db.insert(Suggest, null, values);
         }
     }
     
    /**
    * Get all data in database
    */
    public ArrayList<String> getAllData() {
        ArrayList<String> result = new ArrayList<String>();
        Cursor cursor = null;
        cursor = db.query(Suggest, null, null, null, null, null,null);
        if(cursor == null)
        {
            return null;
        }
        
        cursor.moveToFirst();
        int rowCount = cursor.getCount();
        
        for(int i = 0; i < rowCount; i++){
            String paragraph = cursor.getString(cursor.getColumnIndex(TABLE_COLUMNS.PARAGRAPH));
            result.add(paragraph);
            cursor.moveToNext();
        }
        cursor.close();
        return result;
    }
}
