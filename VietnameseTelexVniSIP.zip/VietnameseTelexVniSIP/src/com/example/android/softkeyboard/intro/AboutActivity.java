package com.example.android.softkeyboard.intro;

import java.io.IOException;
import java.io.InputStream;

import com.example.android.softkeyboard.R;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.os.Build;

public class AboutActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.activity_about);			
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);		
		
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
	String strLicense = null;		
		InputStream is = null;
		try {
            is = getAssets().open("license.txt");            
            int size = is.available();            
            byte[] buffer = new byte[size];
            is.read(buffer);            
            strLicense = new String(buffer);                       
			PackageInfo pi;			
			pi = getPackageManager().getPackageInfo(getPackageName(), 0);												
        } catch (IOException e) {        	
            throw new RuntimeException(e);            
        } catch (NameNotFoundException e) {
			
		} finally {
			try {
				if(is != null)
					is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}			
		}
		
        TextView txtLicense = (TextView)findViewById(R.id.opensource_license); 
        
		if(strLicense != null)   
        	txtLicense.setText(strLicense);

		super.onResume();
	}
}
