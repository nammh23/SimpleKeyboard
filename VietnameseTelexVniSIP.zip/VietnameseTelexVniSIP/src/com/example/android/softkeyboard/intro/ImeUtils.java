package com.example.android.softkeyboard.intro;

import android.content.Context;
import android.provider.Settings;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;

public class ImeUtils {
	
	public static boolean isThisImeEnabled(final Context context,
			final InputMethodManager imm) {
		final String packageName = context.getPackageName();
		for (final InputMethodInfo imi : imm.getEnabledInputMethodList()) {
			if (packageName.equals(imi.getPackageName())) {
				return true;
			}
		}
		return false;
	}

	public static boolean isThisImeCurrent(final Context context,
			final InputMethodManager imm) {
		final InputMethodInfo imi = getInputMethodInfoOf(
				context.getPackageName(), imm);
		final String currentImeId = Settings.Secure.getString(
				context.getContentResolver(),
				Settings.Secure.DEFAULT_INPUT_METHOD);
		return imi != null && imi.getId().equals(currentImeId);
	}

	static InputMethodInfo getInputMethodInfoOf(final String packageName,
			final InputMethodManager imm) {
		for (final InputMethodInfo imi : imm.getInputMethodList()) {
			if (packageName.equals(imi.getPackageName())) {
				return imi;
			}
		}
		return null;
	}

}
