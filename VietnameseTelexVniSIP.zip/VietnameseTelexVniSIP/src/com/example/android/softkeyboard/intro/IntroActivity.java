package com.example.android.softkeyboard.intro;


import com.example.android.softkeyboard.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils.TruncateAt;
import android.transition.Visibility;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;

public class IntroActivity extends Activity implements OnClickListener {
	private Button turn_on_IME_btn = null;
	private Button choose_IME_btn = null;
	private static final int myRequestCode = 1;
	private InputMethodManager mImm;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		setTheme(android.R.style.Theme_Translucent_NoTitleBar);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setup_for_first_time);
		mImm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
		turn_on_IME_btn = (Button) findViewById(R.id.turn_on_IME);
		choose_IME_btn = (Button) findViewById(R.id.choose_IME);
		
		turn_on_IME_btn.setOnClickListener(this);
		choose_IME_btn.setOnClickListener(this);
		
		choose_IME_btn.setEnabled(false);
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		switch (arg0.getId()) {
		case R.id.turn_on_IME:		
			turnOnIME();
			break;
		case R.id.choose_IME:			
			chooseIME();
			break;
		default:
			break;
		}
	}
    
	@Override
	protected void onResume() {
		
		// TODO Auto-generated method stub		
		if(ImeUtils.isThisImeEnabled(this, mImm)){
			choose_IME_btn.setEnabled(true);
		}
		
		if(ImeUtils.isThisImeCurrent(this, mImm)){			
			setResult(RESULT_OK);
			setFirstTimePreference(this);	
			finish();
		}
		super.onResume();
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		
		if(ImeUtils.isThisImeCurrent(this, mImm)){
			setResult(RESULT_OK);
			setFirstTimePreference(this);						
		}
		else{
			setResult(RESULT_CANCELED);
		}
		super.onBackPressed();
	}	
	
	
	private void chooseIME() {
		InputMethodManager imeManager = (InputMethodManager) getBaseContext()
				.getSystemService(INPUT_METHOD_SERVICE);
		if (imeManager != null) {
			imeManager.showInputMethodPicker();
		} else {
			Toast.makeText(getBaseContext(), "Can't show ime",
					Toast.LENGTH_LONG).show();
		}		
		
	}
	
	private void turnOnIME(){
		 final Intent intent = new Intent();
	        intent.setAction(Settings.ACTION_INPUT_METHOD_SETTINGS);
	        intent.addCategory(Intent.CATEGORY_DEFAULT);
	        startActivity(intent);
	}	

	private void setFirstTimePreference(Context context){
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);		
		SharedPreferences.Editor editor = sp.edit();
		editor.putBoolean("FIRST_TIME", false);
		editor.commit();
	}
}
