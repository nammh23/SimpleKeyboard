package com.example.android.softkeyboard.datamodel;

public class UserSelectedWord {

    String composing;
    String composingNormal;
    int typeOfWord;
    
    public UserSelectedWord() {
        
    }
    public UserSelectedWord(String composing, String composingNormal, int typeOfWord) {
        super();
        this.composing = composing;
        this.composingNormal = composingNormal;
        this.typeOfWord = typeOfWord;
    }
    public String getComposing() {
        return composing;
    }
    public void setComposing(String composing) {
        this.composing = composing;
    }
    
    public void setUserSelectedWord(String composing, String composingNormal, int typeOfWord) {
        this.composing = composing;
        this.composingNormal = composingNormal;
        this.typeOfWord = typeOfWord;
    }
    
    public String getComposingNormal() {
        return composingNormal;
    }
    public void setComposingNormal(String composingNormal) {
        this.composingNormal = composingNormal;
    }
    public int getTypeOfWord() {
        return typeOfWord;
    }
    public void setTypeOfWord(int typeOfWord) {
        this.typeOfWord = typeOfWord;
    }
    
}
