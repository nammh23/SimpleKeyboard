package com.example.android.softkeyboard.datamodel;

public class WordType {
	private String word = "";
	private int type = 0;
	
	public WordType(){
		
	}
	
	public void setWordType(String word, int type){
		this.word = word;
		this.type = type;
	}
	
	public void setWord(String word){
		this.word = word;
	}
	public String getWord(){
		return this.word;
	}
	
	public void setType(int type){
		this.type = type;
	}
	public int getType(){
		return this.type;
	}
}
