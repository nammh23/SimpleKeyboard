/*
 * Copyright (C) 2008-2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.softkeyboard;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.Keyboard.Key;
import android.inputmethodservice.KeyboardView;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.text.method.MetaKeyKeyListener;
import android.util.Log;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.CompletionInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import com.example.android.softkeyboard.datamodel.UserSelectedWord;
import com.example.android.softkeyboard.sqlitehelper.SuggestNextWordDAO;
import com.example.android.softkeyboard.sqlitehelper.WordDAO;

/**
 * Example of writing an input method for a soft keyboard. This code is focused
 * on simplicity over completeness, so it should in no way be considered to be a
 * complete soft keyboard implementation. Its purpose is to provide a basic
 * example for how you would get started writing an input method, to be fleshed
 * out as appropriate.
 */
@SuppressLint({ "NewApi", "DefaultLocale", "HandlerLeak" })
public class SoftKeyboard extends InputMethodService implements
		KeyboardView.OnKeyboardActionListener {
	static final boolean DEBUG = false;

	/**
	 * This boolean indicates the optional example code for performing
	 * processing of hard keys in addition to regular text generation from
	 * on-screen interaction. It would be used for input methods that perform
	 * language translations (such as converting text entered on a QWERTY
	 * keyboard to Chinese), but may not be used for input methods that are
	 * primarily intended to be used for on-screen text entry.
	 */
	static final boolean PROCESS_HARD_KEYS = true;
	
	private InputMethodManager mInputMethodManager;
	private static AudioManager mAudioManager;
	private static Vibrator mVibrator;

	/* Input view and 3 key back ground style for setting*/
	private LatinKeyboardView mCurrentInputView;
	private LatinKeyboardView mInputViewHeart;
	private LatinKeyboardView mInputViewBlue;
	private LatinKeyboardView mInputViewNomal;
	private LatinKeyboardView mInputViewViolet;
	private LatinKeyboardView mInputViewLightBlue;
	private LatinKeyboardView mInputViewWhiteBlack;
	
	private CandidateView mCandidateView;
	private CompletionInfo[] mCompletions;
	private StringBuilder mComposing = new StringBuilder();
	private boolean mPredictionOn;
	private boolean mSettingPrediction = false;
	private boolean mCheckWordExistInDictionary = false;
	private boolean mSettingAutoStudying = true;
	private boolean mCompletionOn;
	private int mLastDisplayWidth;
	private boolean mCapsLock;
	private long mLastShiftTime;
	private long mMetaState;
	private int styleKeyboard;
	private int telexOrVNI = HandleVietnameseCharacter.INPUT_METHOD_AUTO;
	private int typingLanguage = HandleVietnameseCharacter.KEYBOARD_BASIC;
	private int mShiftKeyBoard;
	private boolean mIsSymbolShifted;

	private LatinKeyboard mSymbolsKeyboard;
	private LatinKeyboard mSymbolsShiftedKeyboard;
	private LatinKeyboard mQwertyKeyboardTelex;
	private LatinKeyboard mQwertyKeyboardVNI;
	private LatinKeyboard mQwertyKeyboardFull;
	private LatinKeyboard mKeyboardPhone;
	
	private LatinKeyboard mCurKeyboard;

	private String mWordSeparators;

	private StringBuilder mComposingNormal = new StringBuilder();
	private boolean englishMode = false;
	private boolean characterPreview = false;
	private boolean autoSwitchEnVi = true;
	private boolean chooseComposing = false;

	private boolean isPhoneInput = false;
	private boolean enableSound = true;
	private boolean enableVibrate = true;
	private int ringerMode = 0;
	private ArrayList<String> suggestWord = new ArrayList<String>();
	private ArrayList<String> list = new ArrayList<String>();
//	private WordType preComposing = new WordType();
	private UserSelectedWord preComposing = new UserSelectedWord("", "", -1);
	private ArrayList<UserSelectedWord> userSelectedWord = new ArrayList<UserSelectedWord>();
	private HandleVietnameseCharacter mHVC;
	private WordDAO wordDAO = null;
	private SuggestNextWordDAO suggestNextWordDAO = null;
	private Context mContext;
	
	private static final int HANDLE_LONG_CLICK_DELETE = 1;
	private static final int HANDLE_LONG_CLICK_DONE = HANDLE_LONG_CLICK_DELETE + 1;
	private static final int HANDLE_PLAY_SOUND = HANDLE_LONG_CLICK_DONE + 1;
	private static final int HANDLE_GET_ALL_DATA_FROM_DATABASE = HANDLE_PLAY_SOUND + 1;
	private static final int HANDLE_INSERT_DATA_TO_DATABASE = HANDLE_GET_ALL_DATA_FROM_DATABASE + 1;
	private static final int HANDLE_UPDATE_CANDIDATES = HANDLE_INSERT_DATA_TO_DATABASE + 1;
	private static final int HANDLE_ADD_WORD_TO_ARRAYLIST_SUGGEST = HANDLE_UPDATE_CANDIDATES + 1;
	
	
	private boolean isLongDelete = false;
	private boolean isLongUndo = false;
	private boolean alreadyUNDO = true;
	private boolean fixWord = false;
	private int countDelete = 0;
	private int positonCursor = 0;
	private Message message;
	private String deleteString[] = new String[16];
	private int countUndo = 0;
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == HANDLE_LONG_CLICK_DELETE && isLongDelete) {
		        message = mHandler.obtainMessage(HANDLE_LONG_CLICK_DELETE, null);
		        if(countDelete < 15)
		        	countDelete ++;
				if(countDelete >= 15){
					getCurrentInputConnection().setSelection(0, positonCursor);
					if(getCurrentInputConnection().getSelectedText(0) != null){
						countUndo = 15;
						deleteString[countUndo] = getCurrentInputConnection().getSelectedText(0).toString();
					}
					handleBackspace();
				}
				else if(countDelete >= 0 && getCurrentInputConnection().getTextBeforeCursor(10, 0) != null){
					String str = getCurrentInputConnection().getTextBeforeCursor(10, 0).toString();
					String currentWord = breakCurrentWord(str);
	                countUndo = countDelete;
	                if(currentWord != null){
	                    getCurrentInputConnection().setSelection(positonCursor - currentWord.length(), positonCursor);
	                    deleteString[countUndo] = currentWord;
	                }else{
	                	CharSequence temp = getCurrentInputConnection().getTextBeforeCursor(1, 0);
	                	if(temp != null)
	                		deleteString[countUndo] = "" + temp;
	                	else
	                		deleteString[countUndo] = " ";
	                }
					handleBackspace();
					mHandler.sendMessageDelayed(message, 50);
				}else{
					handleBackspace();
					mHandler.sendMessageDelayed(message, 10);
				}
				
			} else if (msg.what == HANDLE_LONG_CLICK_DONE && isLongUndo){
				if(countUndo > 0){
					message = mHandler.obtainMessage(HANDLE_LONG_CLICK_DONE, null);
					if(deleteString[countUndo]!=null){
						mComposing.append(deleteString[countUndo]);
						mComposingNormal.append(deleteString[countUndo]);
						getCurrentInputConnection().commitText(mComposing, 1);
					}
					countUndo--;
					mHandler.sendMessageDelayed(message, 100);
				}
				else
					alreadyUNDO = false;
//				String temp = beforeDelete.replace(afterDelete, "");
//				mComposing.append(temp);
//				mComposingNormal.append(temp);
//				getCurrentInputConnection().commitText(mComposing, 1);
//				alreadyUNDO = false;
			} else if (msg.what == HANDLE_PLAY_SOUND){
				playSoundEffect(SoftKeyboard.this, ringerMode);
			} else if (msg.what == HANDLE_GET_ALL_DATA_FROM_DATABASE) {
			    try {
                    userSelectedWord = wordDAO.getAllData();
                    suggestWord = suggestNextWordDAO.getAllData();
                } catch (Exception e) {
                    Log.e("Handler", "Database don't create complete");
                }
			} else if (msg.what == HANDLE_INSERT_DATA_TO_DATABASE) {
			    try {
		            String longBeforeText = getCurrentInputConnection().getTextBeforeCursor(positonCursor, 0).toString();
		            if (longBeforeText != null) {
		                suggestNextWordDAO.insertData(longBeforeText, -1);
		            }
		        } catch (Exception e) {
		            Log.e("HANDLE_INSERT_DATA_TO_DATABASE", "error when insert paragraph");
		        }
			    
			    wordDAO.reset();
                for (int i = 0; i < userSelectedWord.size(); i++) {
                    try {
                        wordDAO.insertData(userSelectedWord.get(i));
                    } catch (NullPointerException e) {
                        Log.e("onWindowHidden", "NullPointerException");
                    }
                }
			} else if (msg.what == HANDLE_UPDATE_CANDIDATES) {
			    updateCandidates();
			} else if (msg.what == HANDLE_ADD_WORD_TO_ARRAYLIST_SUGGEST) {
			    updateCandidates();
			    
			    if ((preComposing.getTypeOfWord() == 1 || preComposing.getTypeOfWord() == 0) && mSettingAutoStudying) {
                    for (int i = 0; i < userSelectedWord.size(); i++) {
                        if (userSelectedWord.get(i).getComposing().equals(preComposing.getComposing())
                                || userSelectedWord.get(i).getComposingNormal().equals(preComposing.getComposingNormal())) {
                            userSelectedWord.remove(i);
                            break;
                        }
                    }
                    UserSelectedWord tempPre = new UserSelectedWord();
                    tempPre.setUserSelectedWord(preComposing.getComposing(), 
                            preComposing.getComposingNormal(), 
                            preComposing.getTypeOfWord());
                    userSelectedWord.add(tempPre);
                    if (userSelectedWord.size() > 500) {
                        for (int i = 0; i < 50; i++) {
                            userSelectedWord.remove(i);
                        }
                    }
                }
			}
		}
	};
	
	/**
	 * Main initialization of the input method component. Be sure to call to
	 * super class.
	 */
	@Override
	public void onCreate() {
		super.onCreate();
		mInputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
		mAudioManager = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
		mVibrator = (Vibrator) this.getSystemService(Context.VIBRATOR_SERVICE);
		mWordSeparators = getResources().getString(R.string.word_separators);
		mHVC = new HandleVietnameseCharacter(this);
		mContext = this;
		
		try {
			wordDAO = new WordDAO(mContext);
            suggestNextWordDAO = new SuggestNextWordDAO(this);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}

	/**
	 * This is the point where you can do all of your UI initialization. It is
	 * called after creation and any configuration change.
	 */
	@Override
	public void onInitializeInterface() {
		if (mQwertyKeyboardTelex != null) {
			// Configuration changes can happen after the keyboard gets
			// recreated,
			// so we need to be able to re-build the keyboards if the available
			// space has changed.
			int displayWidth = getMaxWidth();
			if (displayWidth == mLastDisplayWidth)
				return;
			mLastDisplayWidth = displayWidth;
		}
		mQwertyKeyboardFull = new LatinKeyboard(this, R.xml.qwerty_full);
		mQwertyKeyboardVNI = new LatinKeyboard(this, R.xml.qwerty_vni);
		mQwertyKeyboardTelex = new LatinKeyboard(this, R.xml.qwerty);
		mSymbolsKeyboard = new LatinKeyboard(this, R.xml.symbol);
		mSymbolsShiftedKeyboard = new LatinKeyboard(this, R.xml.symbols_shift);
		mKeyboardPhone = new LatinKeyboard(this, R.xml.phone_numbers);
	}

	/**
	 * Called by the framework when your view for creating input needs to be
	 * generated. This will be called the first time your input method is
	 * displayed, and every time it needs to be re-created such as due to a
	 * configuration change.
	 */
	@Override
	public View onCreateInputView() {
		styleKeyboard = PreferenceManager.getDefaultSharedPreferences(
				getApplicationContext()).getInt("STYLE_KEYBOARD",
				R.layout.input_nomal);
		mInputViewHeart = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input_heart, null);
		mInputViewBlue = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input_blue, null);
		mInputViewNomal = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input_nomal, null);
		mInputViewViolet = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input_violet, null);
		mInputViewLightBlue = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input_light_blue, null);
		mInputViewWhiteBlack = (LatinKeyboardView) getLayoutInflater().inflate(
				R.layout.input_whileblack, null);
		
		if(styleKeyboard == 0){
			mCurrentInputView = mInputViewBlue;
		}else if(styleKeyboard == 2){
			mCurrentInputView = mInputViewHeart;
		}else if(styleKeyboard == 3){
			mCurrentInputView = mInputViewViolet;
		}else if(styleKeyboard == 4){
			mCurrentInputView = mInputViewLightBlue;
		}else if(styleKeyboard == 5){
			mCurrentInputView = mInputViewWhiteBlack;
		}else{
			mCurrentInputView = mInputViewNomal;
		}

		mCurrentInputView.setOnKeyboardActionListener(this);
		mCurrentInputView.setKeyboard(mQwertyKeyboardTelex);
		
		characterPreview = PreferenceManager.getDefaultSharedPreferences(
				getApplicationContext()).getBoolean("CHARACTER_PREVIEW", false);
		if(characterPreview == true){
			mCurrentInputView.setPreviewEnabled(true);
		}else{
			mCurrentInputView.setPreviewEnabled(false);
		}
		
		autoSwitchEnVi = PreferenceManager.getDefaultSharedPreferences(
				getApplicationContext()).getBoolean("AUTO_SWITCH_ENVI", true);
		
		return mCurrentInputView;
	}

	/**
	 * Called by the framework when your view for showing candidates needs to be
	 * generated, like {@link #onCreateInputView}.
	 */
	@Override
	public View onCreateCandidatesView() {
		mCandidateView = new CandidateView(this);
		mCandidateView.setService(this);
		return mCandidateView;
	}
	
	@Override 
	public void onComputeInsets(InputMethodService.Insets outInsets) {
	    super.onComputeInsets(outInsets);
	    if (!isFullscreenMode()) {
	        outInsets.contentTopInsets = outInsets.visibleTopInsets;
	    }
	}

	/**
	 * This is the main point where we do our initialization of the input method
	 * to begin operating on an application. At this point we have been bound to
	 * the client, and are now receiving all of the detailed information about
	 * the target of our edits.
	 */
	@Override
	public void onStartInput(EditorInfo attribute, boolean restarting) {
		super.onStartInput(attribute, restarting);
		
		englishMode = PreferenceManager.getDefaultSharedPreferences(
				getApplicationContext()).getBoolean("ENGLISH_MODE", false);
		
		// Reset our state. We want to do this even if restarting, because
		// the underlying state of the text editor could have changed in any
		// way.
		mComposing.setLength(0);
		mComposingNormal.setLength(0);
		updateCandidates();
		
		if (!restarting) {
			// Clear shift states.
			mMetaState = 0;
		}

		mPredictionOn = false;
		mCompletionOn = false;
		mCompletions = null;
		// We are now going to initialize our state based on the typeOfWord of
		// text being edited.
		switch (attribute.inputType & InputType.TYPE_MASK_CLASS) {
		case InputType.TYPE_CLASS_NUMBER:
		case InputType.TYPE_CLASS_DATETIME:
			// Numbers and dates default to the symbols keyboard, with
			// no extra features.
			mCurKeyboard = mSymbolsKeyboard;
			PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
								.edit().putBoolean("IS_PHONE_INPUT", false).commit();
			break;

		case InputType.TYPE_CLASS_PHONE:
			// Phones will also default to the symbols keyboard, though
			// often you will want to have a dedicated phone keyboard.
			mCurKeyboard = mKeyboardPhone;
			PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
								.edit().putBoolean("IS_PHONE_INPUT", true).commit();
			break;

		case InputType.TYPE_CLASS_TEXT:
			// This is general text editing. We will default to the
			// normal alphabetic keyboard, and assume that we should
			// be doing predictive text (showing candidates as the
			// user types).
			typingLanguage = PreferenceManager.getDefaultSharedPreferences(
					getApplicationContext()).getInt("TYPING_LANGUAGE", 0);
			PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
								.edit().putBoolean("IS_PHONE_INPUT", false).commit();
			if(mShiftKeyBoard == 0) {
				if (typingLanguage == HandleVietnameseCharacter.KEYBOARD_NO_NUMBERIC) {
					mCurKeyboard = mQwertyKeyboardTelex;
				} else if (typingLanguage == HandleVietnameseCharacter.KEYBOARD_BASIC) {
					mCurKeyboard = mQwertyKeyboardVNI;
				} else {
					mCurKeyboard = mQwertyKeyboardFull;
					englishMode = false;
				}
			} else {
				if(mIsSymbolShifted) {
					mCurKeyboard = mSymbolsShiftedKeyboard;
				} else {
					mCurKeyboard = mSymbolsKeyboard;
				}
			}
			mPredictionOn = true;
			// We now look for a few special variations of text that will
			// modify our behavior.
			int variation = attribute.inputType & InputType.TYPE_MASK_VARIATION;
			if (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD
					|| variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
				// Do not display predictions / what the user is typing
				// when they are entering a password.
				mPredictionOn = false;
			}

//			if (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
//					|| variation == InputType.TYPE_TEXT_VARIATION_URI
//					|| variation == InputType.TYPE_TEXT_VARIATION_FILTER) {
//				// Our predictions are not useful for e-mail addresses
//				// or URIs.
//				mPredictionOn = false;
//			}
//
//			if ((attribute.inputType & InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE) != 0) {
//				// If this is an auto-complete text view, then our predictions
//				// will not be shown and instead we will allow the editor
//				// to supply their own. We only show the editor's
//				// candidates when in fullscreen mode, otherwise relying
//				// own it displaying its own UI.
//				mPredictionOn = false;
//				mCompletionOn = isFullscreenMode();
//			}

			// We also want to look at the current state of the editor
			// to decide whether our alphabetic keyboard should start out
			// shifted.
			updateShiftKeyState(attribute);
			break;

		default:
			// For all unknown input types, default to the alphabetic
			// keyboard with no special features.
			mCurKeyboard = mQwertyKeyboardTelex;
			PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
								.edit().putBoolean("IS_PHONE_INPUT", false).commit();
			updateShiftKeyState(attribute);
		}

		// Update the label on the enter key, depending on what the application
		// says it will do.
		mCurKeyboard.setImeOptions(getResources(), attribute.imeOptions);
	}

	/**
	 * This is called when the user is done editing a field. We can use this to
	 * reset our state.
	 */
	@Override
	public void onFinishInput() {
		super.onFinishInput();

		// Clear current composing text and candidates.
		mComposing.setLength(0);
		mComposingNormal.setLength(0);
		updateCandidates();
		
		// We only hide the candidates window when finishing input on
		// a particular editor, to avoid popping the underlying application
		// up and down if the user is entering text into the bottom of
		// its window.
		setCandidatesViewShown(false);

		mCurKeyboard = mQwertyKeyboardTelex;
		if (mCurrentInputView != null) {
			mCurrentInputView.closing();
		}

	}

	@Override
	public void onStartInputView(EditorInfo attribute, boolean restarting) {
		//super.onStartInputView(attribute, restarting);
		// Apply the selected keyboard to the input view.	
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(getApplicationContext());	
		mSettingPrediction = sp.getBoolean("PREDICT_TEXT", true);
		mSettingAutoStudying = sp.getBoolean("AUTO_STUDYING", true);
		telexOrVNI = sp.getInt("TELEX_VNI", 0);
		enableSound = sp.getBoolean("PLAY_SOUND", true);
		enableVibrate = sp.getBoolean("VIBRATION", true);
		ringerMode = mAudioManager.getRingerMode();
		
		setCandidatesViewShown(mSettingPrediction && !isPhoneInput);		
		if(mCurKeyboard != mKeyboardPhone) {
			setCandidatesViewShown(mSettingPrediction);
		}else{
			setCandidatesViewShown(false);
		}
		setInputView(onCreateInputView());
		mCurrentInputView.setKeyboard(mCurKeyboard);
		mCurrentInputView.closing();

		if (englishMode == true) {
			mCurKeyboard.setViEnLabel("EN");
		} else {
			mCurKeyboard.setViEnLabel("VI");
		}
		mCurrentInputView.invalidateAllKeys();
		updateShiftKeyState(getCurrentInputEditorInfo());
	}

	@Override
	public void onCurrentInputMethodSubtypeChanged(InputMethodSubtype subtype) {
		// mCurrentInputView.setSubtypeOnSpaceKey(subtype);
	}

	/**
	 * Deal with the editor reporting movement of its cursor.
	 */
	@Override
	public void onUpdateSelection(int oldSelStart, int oldSelEnd,
			int newSelStart, int newSelEnd, int candidatesStart,
			int candidatesEnd) {
		super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
				candidatesStart, candidatesEnd);
		positonCursor = newSelStart;
		
		if((newSelStart - oldSelStart) > 1 || (oldSelStart - newSelStart) >= 1){
			fixWord = true;
		}

		// If the current selection in the text view changes, we should
		// clear whatever candidate text we have.
		if (mComposing.length() > 0
				&& (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
			mComposing.setLength(0);
			mComposingNormal.setLength(0);
			InputConnection ic = getCurrentInputConnection();
			if (ic != null) {
				ic.finishComposingText();
			}
		}
		updateShiftKeyState(getCurrentInputEditorInfo());
	}

	/**
	 * This tells us about completions that the editor has determined based on
	 * the current text in it. We want to use this in fullscreen mode to show
	 * the completions ourself, since the editor can not be seen in that
	 * situation.
	 */
	@Override
	public void onDisplayCompletions(CompletionInfo[] completions) {
		if (mCompletionOn) {
			mCompletions = completions;
			if (completions == null) {
				setSuggestions(null, false, false);
				return;
			}

			List<String> stringList = new ArrayList<String>();
			for (int i = 0; i < completions.length; i++) {
				CompletionInfo ci = completions[i];
				if (ci != null)
					stringList.add(ci.getText().toString());
			}
			setSuggestions(stringList, true, true);
		}
	}

	/**
	 * This translates incoming hard key events in to edit operations on an
	 * InputConnection. It is only needed when using the PROCESS_HARD_KEYS
	 * option.
	 */
	private boolean translateKeyDown(int keyCode, KeyEvent event) {
		mMetaState = MetaKeyKeyListener.handleKeyDown(mMetaState, keyCode,
				event);
		int c = event.getUnicodeChar(MetaKeyKeyListener
				.getMetaState(mMetaState));
		mMetaState = MetaKeyKeyListener.adjustMetaAfterKeypress(mMetaState);
		InputConnection ic = getCurrentInputConnection();
		if (c == 0 || ic == null) {
			return false;
		}

		boolean dead = false;

		if ((c & KeyCharacterMap.COMBINING_ACCENT) != 0) {
			dead = true;
			c = c & KeyCharacterMap.COMBINING_ACCENT_MASK;
		}

		if (mComposing.length() > 0) {
			char accent = mComposing.charAt(mComposing.length() - 1);
			int composed = KeyEvent.getDeadChar(accent, c);

			if (composed != 0) {
				c = composed;
				mComposing.setLength(mComposing.length() - 1);
			}
		}

		onKey(c, null);

		return true;
	}

	/**
	 * Use this to monitor key events being delivered to the application. We get
	 * first crack at them, and can either resume them or let them continue to
	 * the app.
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			// The InputMethodService already takes care of the back
			// key for us, to dismiss the input method if it is shown.
			// However, our keyboard could be showing a pop-up window
			// that back should dismiss, so we first allow it to do that.
			if (event.getRepeatCount() == 0 && mCurrentInputView != null) {
				if (mCurrentInputView.handleBack()) {
					return true;
				}
			}
			break;

		case KeyEvent.KEYCODE_DEL:
			// Special handling of the delete key: if we currently are
			// composing text for the user, we want to modify that instead
			// of let the application to the delete itself.
			if (mComposing.length() > 0) {
				onKey(Keyboard.KEYCODE_DELETE, null);
				return true;
			}
			break;

		case KeyEvent.KEYCODE_ENTER:
			// Let the underlying text editor always handle these.
			return false;

		default:
			// For all other keys, if we want to do transformations on
			// text being entered with a hard keyboard, we need to process
			// it and do the appropriate action.
			if (PROCESS_HARD_KEYS) {
				if (keyCode == KeyEvent.KEYCODE_SPACE
						&& (event.getMetaState() & KeyEvent.META_ALT_ON) != 0) {
					// A silly example: in our input method, Alt+Space
					// is a shortcut for 'android' in lower case.
					InputConnection ic = getCurrentInputConnection();
					if (ic != null) {
						// First, tell the editor that it is no longer in the
						// shift state, since we are consuming this.
						ic.clearMetaKeyStates(KeyEvent.META_ALT_ON);
						keyDownUp(KeyEvent.KEYCODE_A);
						keyDownUp(KeyEvent.KEYCODE_N);
						keyDownUp(KeyEvent.KEYCODE_D);
						keyDownUp(KeyEvent.KEYCODE_R);
						keyDownUp(KeyEvent.KEYCODE_O);
						keyDownUp(KeyEvent.KEYCODE_I);
						keyDownUp(KeyEvent.KEYCODE_D);
						// And we consume this event.
						return true;
					}
				}
				if (mPredictionOn && translateKeyDown(keyCode, event)) {
					return true;
				}
			}
		}

		return super.onKeyDown(keyCode, event);
	}

	/**
	 * Use this to monitor key events being delivered to the application. We get
	 * first crack at them, and can either resume them or let them continue to
	 * the app.
	 */
	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		// If we want to do transformations on text being entered with a hard
		// keyboard, we need to process the up events to update the meta key
		// state we are tracking.
		if (PROCESS_HARD_KEYS) {
			if (mPredictionOn) {
				mMetaState = MetaKeyKeyListener.handleKeyUp(mMetaState,
						keyCode, event);
			}
		}

		return super.onKeyUp(keyCode, event);
	}

	/**
	 * Helper function to commit any text being composed in to the editor.
	 */
	private void commitTyped(InputConnection inputConnection) {
		if (mComposing.length() > 0) {
			UserSelectedWord temp = new UserSelectedWord();
			temp.setUserSelectedWord(preComposing.getComposing(), 
			        preComposing.getComposingNormal(), 
			        preComposing.getTypeOfWord());
			
			if(chooseComposing){
				getCurrentInputConnection().commitText(mComposing, 1);
				preComposing.setUserSelectedWord(mComposing.toString().toLowerCase(), 
						mComposingNormal.toString().toLowerCase(), 0);
			}else{
				getCurrentInputConnection().commitText(mComposingNormal, 1);
				preComposing.setUserSelectedWord(mComposing.toString().toLowerCase(), 
						mComposingNormal.toString().toLowerCase(), 1);
			}
			
//			preComposing = mHVC.handleCommitViEn(mComposing, mComposingNormal, inputConnection, preComposing, englishMode, getTypeOfWordUserChoise(mComposing.toString().toLowerCase()));
//			preComposing = mHVC.handleCommitViEn(mComposing, mComposingNormal, inputConnection, preComposing, englishMode, wordDAO.getData(mComposing.toString()));
			mComposing.setLength(0);
			mComposingNormal.setLength(0);
			
			if((temp.getTypeOfWord() == preComposing.getTypeOfWord() && temp.getTypeOfWord() == 0 && englishMode == true)
					|| (temp.getTypeOfWord() == preComposing.getTypeOfWord() && temp.getTypeOfWord() == 1 && englishMode == false)){
				changeViEnMode();
			}
			
			message = mHandler.obtainMessage(HANDLE_ADD_WORD_TO_ARRAYLIST_SUGGEST, null);
	        mHandler.sendMessage(message);
		}
	}
	
	/**
	 * Helper to update the shift state of our keyboard based on the initial
	 * editor state.
	 */
	private void updateShiftKeyState(EditorInfo attr) {
		if (attr != null
				&& mCurrentInputView != null
				&& (mQwertyKeyboardTelex == mCurrentInputView.getKeyboard() 
				|| mQwertyKeyboardVNI == mCurrentInputView.getKeyboard()
				|| mQwertyKeyboardFull == mCurrentInputView.getKeyboard())) {
			int caps = 0;
			EditorInfo ei = getCurrentInputEditorInfo();
			if (ei != null && ei.inputType != InputType.TYPE_NULL) {
				caps = getCurrentInputConnection().getCursorCapsMode(
						attr.inputType);
			}
			mCurrentInputView.setShifted(mCapsLock || caps != 0);
		}
	}

	/**
	 * Helper to determine if a given character code is alphabetic.
	 */
	private boolean isAlphabet(int code) {
		if (Character.isLetter(code)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Helper to send a key down / key up pair to the current editor.
	 */
	private void keyDownUp(int keyEventCode) {
		getCurrentInputConnection().sendKeyEvent(
				new KeyEvent(KeyEvent.ACTION_DOWN, keyEventCode));
		getCurrentInputConnection().sendKeyEvent(
				new KeyEvent(KeyEvent.ACTION_UP, keyEventCode));
	}

	/**
	 * Helper to send a character to the editor as raw key events.
	 */
	private void sendKey(int keyCode) {
		switch (keyCode) {
		case '\n':
			keyDownUp(KeyEvent.KEYCODE_ENTER);
			break;
		default:
			if (keyCode >= '0' && keyCode <= '9') {
				keyDownUp(keyCode - '0' + KeyEvent.KEYCODE_0);
			} else {
				getCurrentInputConnection().commitText(
						String.valueOf((char) keyCode), 1);
			}
			break;
		}
	}

	// Implementation of KeyboardViewListener

	public void onKey(int primaryCode, int[] keyCodes) {
		if (isWordSeparator(primaryCode)) {
			// Handle separator
			if (mComposing.length() > 0) {
				commitTyped(getCurrentInputConnection());
			}
			sendKey(primaryCode);
		} else if (primaryCode == Keyboard.KEYCODE_DELETE || primaryCode == 8) {
			if(!isLongDelete){
				handleBackspace();
				countUndo = 0;
			}
		} else if (primaryCode == Keyboard.KEYCODE_SHIFT || primaryCode == -4
				|| primaryCode == -8) {
			handleShift();
		} else if (primaryCode == Keyboard.KEYCODE_CANCEL) {
			handleClose();
			return;
		} else if (primaryCode == LatinKeyboardView.KEYCODE_OPTIONS) {
			showInputMethodPicker();
		} else if (primaryCode == Keyboard.KEYCODE_MODE_CHANGE
				&& mCurrentInputView != null) {
			Keyboard current = mCurrentInputView.getKeyboard();
			if (current == mSymbolsKeyboard
					|| current == mSymbolsShiftedKeyboard) {
				boolean isPhoneInput = PreferenceManager.getDefaultSharedPreferences(
	    				mContext).getBoolean("IS_PHONE_INPUT",false);
				if(!isPhoneInput) {
					if(typingLanguage == HandleVietnameseCharacter.KEYBOARD_NO_NUMBERIC){
						current = mQwertyKeyboardTelex;
					} else if (typingLanguage == HandleVietnameseCharacter.KEYBOARD_BASIC) {
						current = mQwertyKeyboardVNI;
					} else {
						current = mQwertyKeyboardFull;
					}
				} else {
					current = mKeyboardPhone;
				}
				mShiftKeyBoard = 0;
			} else {
				current = mSymbolsKeyboard;
				mShiftKeyBoard = 1;
			}
			mCurrentInputView.setKeyboard(current);
			if (current == mSymbolsKeyboard) {
				current.setShifted(false);
			}
			mCurrentInputView.invalidateAllKeys();
		} else if (primaryCode == 19 || primaryCode == 20 || primaryCode == 21
				|| primaryCode == 22) {
			sendDownUpKeyEvents(primaryCode);
		} else if (primaryCode == -10) {
			Keyboard current = mCurrentInputView.getKeyboard();
			if (current != mQwertyKeyboardFull) {
				changeViEnMode();
			}
		} else if (primaryCode == -11) {
			Intent dialogIntent = new Intent(getApplicationContext(),
					SettingVNI.class);
			dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			getApplication().startActivity(dialogIntent);

		} else if(primaryCode == 10 ){
		
			if(mCurKeyboard.imeOption != EditorInfo.IME_ACTION_GO 
					&& mCurKeyboard.imeOption != EditorInfo.IME_ACTION_NEXT
					&& mCurKeyboard.imeOption != EditorInfo.IME_ACTION_SEARCH
					&& mCurKeyboard.imeOption != EditorInfo.IME_ACTION_SEND
					&& mCurKeyboard.imeOption != EditorInfo.IME_ACTION_DONE){	
				if(!isLongUndo)
					sendKey(primaryCode);
			}
			else{
				getCurrentInputConnection().performEditorAction(mCurKeyboard.imeOption);
			}
		} else {
			handleCharacter(primaryCode, keyCodes);
			countUndo = 0;
		}
	}

	public void onText(CharSequence text) {
		InputConnection ic = getCurrentInputConnection();
		if (ic == null)
			return;
		ic.beginBatchEdit();
		if (mComposing.length() > 0) {
			commitTyped(ic);
		}
		ic.commitText(text, 0);
		ic.endBatchEdit();
	}

	@Override
	public void onWindowHidden() {
		// TODO Auto-generated method stub
		super.onWindowHidden();
		mShiftKeyBoard = 0;
		mIsSymbolShifted = false;
		onStartInput(getCurrentInputEditorInfo(), true);
		preComposing.setUserSelectedWord("", "", -1);

		message = mHandler.obtainMessage(HANDLE_INSERT_DATA_TO_DATABASE, null);
        mHandler.sendMessage(message);
	}

	@Override
	public void onWindowShown() {
		// TODO Auto-generated method stub
		super.onWindowShown();
    	setCandidatesView(onCreateCandidatesView());
    	message = mHandler.obtainMessage(HANDLE_GET_ALL_DATA_FROM_DATABASE, null);
        mHandler.sendMessage(message);
	}
	
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
    	// TODO Auto-generated method stub
		//onConfigurationChanged(null);
    	super.onConfigurationChanged(newConfig);
    	updateShiftKeyState(getCurrentInputEditorInfo());
    	updateCandidates();
    }

    /**
	 * Update the list of available candidates from the current composing text.
	 * This will need to be filled in by however you are determining candidates.
	 */
    private void updateCandidates() {
		if (mSettingPrediction) {
			if (!mCompletionOn) {
			    if (preComposing.getTypeOfWord() == 0) {
    				handleCandidate(mComposing.toString(),
    						mComposingNormal.toString(), preComposing.getComposing());
    		        
			    } else {
			        handleCandidate(mComposing.toString(),
                            mComposingNormal.toString(), preComposing.getComposingNormal());
			    }
			}
		}
	}

	public void setSuggestions(List<String> suggestions, boolean completions,
			boolean typedWordValid) {	
		if (mCandidateView != null) {
			mCandidateView.setSuggestions(suggestions, completions,
					typedWordValid);
		}
	}

	private void handleBackspace() {
		final int length = mComposing.length();
		final int length1 = mComposingNormal.length();
		if (length > 1) {
			
			String handleDel = mHVC.handleDeleteCharacter(mComposing, length);
			mComposing.setLength(0);
			mComposing.append(handleDel);
			
			mComposingNormal.delete(length1 - 1, length1);
			handleSetComposingText(getCurrentInputConnection());
		} else if (length > 0) {
			if(mHVC.positionSign(mComposing, mHVC.VN_VOWELS_SIGN) > -1){
				String handleDel = mHVC.handleDeleteCharacter(mComposing, length);
				mComposing.setLength(0);
				mComposing.append(handleDel);
				
				mComposingNormal.delete(length1 - 1, length1);
				handleSetComposingText(getCurrentInputConnection());
			}else{
				mComposing.setLength(0);
				mComposingNormal.setLength(0);
				getCurrentInputConnection().commitText("", 0);
			}
		} else {
			keyDownUp(KeyEvent.KEYCODE_DEL);
			preComposing.setUserSelectedWord("", "", -1);
		}
		updateCandidates();
	}

	private void handleShift() {
		if (mCurrentInputView == null) {
			return;
		}

		Keyboard currentKeyboard = mCurrentInputView.getKeyboard();
		if (mQwertyKeyboardTelex == currentKeyboard
				|| mQwertyKeyboardVNI == currentKeyboard
				|| mQwertyKeyboardFull == currentKeyboard) {
			// Alphabet keyboard
			checkToggleCapsLock();
			mCurrentInputView.setShifted(mCapsLock || !mCurrentInputView.isShifted());
		} else if (currentKeyboard == mSymbolsKeyboard) {
			mSymbolsKeyboard.setShifted(true);
			mCurrentInputView.setKeyboard(mSymbolsShiftedKeyboard);
			mSymbolsShiftedKeyboard.setShifted(true);
			mIsSymbolShifted = true;
		} else if (currentKeyboard == mSymbolsShiftedKeyboard) {
			mSymbolsShiftedKeyboard.setShifted(false);
			mCurrentInputView.setKeyboard(mSymbolsKeyboard);
			mSymbolsKeyboard.setShifted(false);
			mIsSymbolShifted = false;
		}
	}

	private void handleCharacter(int primaryCode, int[] keyCodes) {
		if (isInputViewShown()) {
			if (mCurrentInputView.isShifted()) {
				primaryCode = Character.toUpperCase(primaryCode);
			}
		}
		if ((isAlphabet(primaryCode)
				|| (primaryCode >= 48 && primaryCode <= 57) || mHVC.isSignCode(primaryCode))
				&& mPredictionOn) {
			
			InputConnection ic = getCurrentInputConnection();
			// Fix word at position of cursor
            if(mComposing.length() == 0 && fixWord){
            	if(ic.getTextBeforeCursor(10, 0) != null){
	                String longBeforeText = ic.getTextBeforeCursor(10, 0).toString();
	                String currentWord = breakCurrentWord(longBeforeText);
	                
	                if(currentWord != null){
	                    mComposing.append(currentWord);
	                    mComposingNormal.append(currentWord);
	                    ic.setComposingRegion(positonCursor - mComposing.length(), positonCursor);
	                }
	                fixWord = false;
            	}
            }
			mHVC.handleVietnameseCharacter(primaryCode, mComposing, telexOrVNI, typingLanguage);
			
			if (!mHVC.isSignCode(primaryCode)) {
				mComposingNormal.append((char) primaryCode);
			}

			if (mComposing.length() > 0) {
				handleSetComposingText(ic);
			}

			//Auto detect TELEX VNI
			if(telexOrVNI == 0) {
				telexOrVNI = mHVC.handleAutoDetectTelexVni(mComposing, mComposingNormal);
			}
			// mComposing.append((char) primaryCode);
			// getCurrentInputConnection().setComposingText(mComposing, 1);
			
			message = mHandler.obtainMessage(HANDLE_UPDATE_CANDIDATES, null);
	        mHandler.sendMessage(message);
	        
		} else {
			if (!mHVC.isSignCode(primaryCode)) {
				if (mComposing.length() > 0) {
					commitTyped(getCurrentInputConnection());
				}
				sendKey(primaryCode);
			}
			// getCurrentInputConnection().commitText(
			// String.valueOf((char) primaryCode), 1);
		}
	}

	private void handleClose() {

		commitTyped(getCurrentInputConnection());
		requestHideSelf(0);
		mCurrentInputView.closing();
	}

	private void checkToggleCapsLock() {
		long now = System.currentTimeMillis();
		if (mLastShiftTime + 800 > now) {
			mCapsLock = !mCapsLock;
			mLastShiftTime = 0;
		} else {
			mLastShiftTime = now;
		}
	}

	private String getWordSeparators() {
		return mWordSeparators;
	}

	public boolean isWordSeparator(int code) {
		String separators = getWordSeparators();
		return separators.contains(String.valueOf((char) code));
	}

	public void pickDefaultCandidate() {
		pickSuggestionManually(0);
	}

	public void pickSuggestionManually(int index) {
		
		message = mHandler.obtainMessage(HANDLE_PLAY_SOUND, null);
		mHandler.sendMessage(message);

		if (mCompletionOn && mCompletions != null && index >= 0
                && index < mCompletions.length) {
            CompletionInfo ci = mCompletions[index];
            getCurrentInputConnection().commitCompletion(ci);
            if (mCandidateView != null) {
                mCandidateView.clear();
            }
            
            preComposing.setComposing(list.get(index));
        } else if (mComposing.length() > 0) {
            // If we were generating candidate suggestions for the current
            // text, we would commit one of them here. But for this sample,
            // we will just commit the current text.
        	
        	if(index < 2 && autoSwitchEnVi && !mComposing.toString().equals(mComposingNormal.toString())){
	            getCurrentInputConnection().setComposingText(list.get(index), 1);
	            if(index == 0){
	            	chooseComposing = true;
	            }else{
	            	chooseComposing = false;
	            }
        	}
            else{
            	getCurrentInputConnection().commitText(list.get(index) + " ", 1);
            }
        	
            UserSelectedWord selectedWord = new UserSelectedWord(mComposing.toString().toLowerCase(), 
                                            mComposingNormal.toString().toLowerCase(), 
                                            index);
            for (int i = 0; i < userSelectedWord.size(); i++) {
                if (userSelectedWord.get(i).getComposing().equals(selectedWord.getComposing())) {
                    userSelectedWord.remove(i);
                    break;
                }
            }
            if ((index == 0 || index == 1) && mSettingAutoStudying) {
                try {
                    userSelectedWord.add(new UserSelectedWord(list.get(0), list.get(1), index));
                } catch (Exception e) {
                    // TODO: handle exception
                }
            }
            // commitTyped(getCurrentInputConnection());          
            if ((index == 0 || index == 1) && autoSwitchEnVi && !mComposing.toString().equals(mComposingNormal.toString())) {
                preComposing.setUserSelectedWord(list.get(0), list.get(1), index);
            } else {
                for (int i = 0; i < userSelectedWord.size(); i++) {
                    if (userSelectedWord.get(i).getComposing().equals(list.get(index))
                            || userSelectedWord.get(i).getComposingNormal().equals(list.get(index))) {
                        preComposing.setUserSelectedWord(userSelectedWord.get(i).getComposing(), userSelectedWord.get(i).getComposingNormal(),
                                userSelectedWord.get(i).getTypeOfWord());
                        break;
                    }
                }
            }
            updateCandidates();
        } else {
            try {
                getCurrentInputConnection().commitText(list.get(index) + " ", 1);
                preComposing.setComposing(list.get(index));
                preComposing.setComposingNormal(list.get(index));
                preComposing.setTypeOfWord(0);
            } catch (Exception e) {
                // TODO: handle exception
            }
            if (englishMode)
                changeViEnMode();
            updateCandidates();
        }
    }

	public void swipeRight() {
		if (mCompletionOn) {
			pickDefaultCandidate();
		}
	}

	public void swipeLeft() {
		handleBackspace();
	}

	public void swipeDown() {
		handleClose();
	}

	public void swipeUp() {
	    handleClose();
	}

	public void onPress(int primaryCode) {
		message = mHandler.obtainMessage(HANDLE_PLAY_SOUND, null);
		mHandler.sendMessage(message);
	}

	public void onRelease(int primaryCode) {
		countDelete = 0;
		alreadyUNDO = false;
		if(isLongDelete){
			alreadyUNDO = true;
			Toast.makeText(getApplicationContext(), "Long click on enter key to UNDO", Toast.LENGTH_SHORT).show();
		}
		isLongDelete = false;
		isLongUndo = false;
	}

	private void showInputMethodPicker() {
		InputMethodManager imeManager = (InputMethodManager) getBaseContext()
				.getSystemService(INPUT_METHOD_SERVICE);
		if (imeManager != null) {
			imeManager.showInputMethodPicker();
		} else {
			Toast.makeText(getBaseContext(), "Can't show ime",
					Toast.LENGTH_LONG).show();
		}
	}
	
	private void changeViEnMode() {
		if (englishMode) {
			englishMode = false;
			mCurKeyboard.setViEnLabel("VI");
			getCurrentInputConnection().setComposingText(mComposing, 1);
			chooseComposing = true;
		} else {
			englishMode = true;
			mCurKeyboard.setViEnLabel("EN");
			getCurrentInputConnection().setComposingText(mComposingNormal, 1);
			chooseComposing = false;
		}
		preComposing.setUserSelectedWord("", "", -1);
		mCurrentInputView.invalidateAllKeys();
		updateCandidates();
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(getApplicationContext());
		sp.edit().putBoolean("ENGLISH_MODE", englishMode).commit();
	}
	
	
	private ArrayList<String> search(String composing) {
	    ArrayList<String> result = new ArrayList<String>();
	    for (int i = 0; i < userSelectedWord.size(); i++) {
	        if (userSelectedWord.get(i).getComposing().startsWith(composing) ||
	                userSelectedWord.get(i).getComposingNormal().startsWith(composing)) {
	            int type = userSelectedWord.get(i).getTypeOfWord();
                if (type == 0) {
                    result.add(userSelectedWord.get(i).getComposing());
                } else {
                    result.add(userSelectedWord.get(i).getComposingNormal());
                }
	        }
	    }
	    
	    return result;
	}
	
	private int getTypeOfWordUserChoise(String composing) {
	    int type = -1;
	    for (int i = 0; i < userSelectedWord.size(); i++) {
	        if (userSelectedWord.get(i).getComposing().equals(composing)) {
	            type = userSelectedWord.get(i).getTypeOfWord();
	            break;
	        }
	    }
	    
	    return type;
	}
	
	private void handleCandidate(String composing, final String composingNormal, String preComposing){
	    ArrayList<String> wordList = new ArrayList<String>();

	    if (mSettingPrediction) {
	        wordList = search(composingNormal);
	    }
	    
		if (composing.length() > 0) {
			if(list != null) {
				list.clear();
			}
			else {
				list = new ArrayList<String>();
			}
			if(autoSwitchEnVi  && !composing.equals(composingNormal)){
				list.add(composing);
				list.add(composingNormal);
			}
			if (mSettingPrediction) {
    			for (int i = 0; i < wordList.size(); i++) {
        	        list.add(wordList.get(i));
        			if (i > 10) {
        			    break;
        			}
    			}
			}
			setSuggestions(list, true, true);
		} else {
		    list = addWordToCandidate(suggestWord, preComposing);
            if (list != null) {
                setSuggestions(list, true, true);
            } else {
                setSuggestions(null, false, false);
            }
		}
	}

	public void playSoundEffect(Service activity, int ringerMode) {
		switch (ringerMode) {
		case AudioManager.RINGER_MODE_NORMAL:
			if (enableSound)
				mAudioManager.playSoundEffect(AudioManager.FX_KEY_CLICK);
			if (enableVibrate) {
				mVibrator.vibrate(10);
			}
			break;
		case AudioManager.RINGER_MODE_SILENT:
			break;
		case AudioManager.RINGER_MODE_VIBRATE:
			if (enableVibrate) {
				mVibrator.vibrate(10);
			}
			break;

		default:
			break;
		}
	}
	
	/**
     * Get word right before cursor
     * @param longBeforeText
     * @return
     */
    private String breakCurrentWord(String longBeforeText) {
        // TODO Auto-generated method stub
        if (longBeforeText == null || longBeforeText.length() == 0) return null;
        else{
            if(longBeforeText.charAt(longBeforeText.length()-1) == ' ') return null;
        	if(longBeforeText.charAt(longBeforeText.length()-1) == '\n') return null;
	        if(isAlphabet(longBeforeText.charAt(longBeforeText.length()-1))){
	            String token = "";
	            longBeforeText = longBeforeText.replace('\n', ' ');
	            String splitString[] = longBeforeText.split(" ");
	            token = splitString[splitString.length - 1];
	            return token;
            }
            else return null;
        }
    }
    
    private void handleSetComposingText(InputConnection ic){
    	if(autoSwitchEnVi){
			chooseComposing = mHVC.autoTransformViEn(mComposing, mComposingNormal, 
					englishMode, getTypeOfWordUserChoise(mComposing.toString().toLowerCase()));
		}
		else{
			if(englishMode) chooseComposing = false;
			else chooseComposing = true;
		}
		
		if(chooseComposing){
			ic.setComposingText(mComposing, 1);
		}else{
			ic.setComposingText(mComposingNormal, 1);
		}
    }
    /**
     * Add word to Candidate
     */
    private ArrayList<String> addWordToCandidate(ArrayList<String> suggestWord, String preComposing) {
        
        ArrayList<String> listWordSuggest = new ArrayList<String>();
        if (preComposing.length() > 0) {
            for (String str : suggestWord) {
                String arrStr[] = str.split(" ");
                for (int i = 0; i < arrStr.length - 1; i++) {
                    if (arrStr[i].toLowerCase().equals(preComposing)) {
                        
                        // Not add if exist
                        boolean checkExist = false;
                        for (String s : listWordSuggest) {
                            if (s.toLowerCase().equals(arrStr[i + 1].toLowerCase())) {
                                checkExist = true;
                                break;
                            }
                        }
                        if (!checkExist && listWordSuggest.size() < 10) {
                            listWordSuggest.add(arrStr[i + 1]);
                        }
                        
                    }
                }
            }
            return listWordSuggest;
        } else {
            return null;
        }
    }

	public void handleLongClickBackspace(){
		
		if(positonCursor > 0 && mCurKeyboard.imeOption != EditorInfo.IME_ACTION_NEXT){
	    	isLongDelete = true;
			if (mComposing.length() > 0) {
				if(chooseComposing){
					getCurrentInputConnection().commitText(mComposing, 1);
				}else{
					getCurrentInputConnection().commitText(mComposingNormal, 1);
				}
				mComposing.setLength(0);
				mComposingNormal.setLength(0);
			}
	    	message = mHandler.obtainMessage(HANDLE_LONG_CLICK_DELETE, null);
			mHandler.sendMessage(message);
		}
	}
	
	public void handleLongClickDone(){
		if(mComposing.length() == 0 && (alreadyUNDO || countUndo > 0)){
			message = mHandler.obtainMessage(HANDLE_LONG_CLICK_DONE, null);
			mHandler.sendMessage(message);
			isLongUndo = true;
		}
	}
}
