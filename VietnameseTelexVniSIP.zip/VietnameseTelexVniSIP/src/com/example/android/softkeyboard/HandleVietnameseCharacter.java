package com.example.android.softkeyboard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;

@SuppressLint("NewApi")
public class HandleVietnameseCharacter {
	
	public static final int KEYBOARD_BASIC = 0;
	public static final int KEYBOARD_NO_NUMBERIC = 1;
	public static final int KEYBOARD_VIETNAMESE = 2;
	
	public static final int INPUT_METHOD_AUTO = 0;
	public static final int INPUT_METHOD_VNI = 1;
	public static final int INPUT_METHOD_TELEX = 2;
	
	public HashMap<String, Integer> englishMap = new HashMap<String, Integer>();
	public HashMap<String, Integer> vietnameseMap = new HashMap<String, Integer>();
	
	private boolean checkVietnameseEqual;
	private boolean checkEnglishEqual;
	
	public HandleVietnameseCharacter(Context context) {
		if (englishMap.size() < 1) {
			Log.d("SIP", "Load word!!!");
			loadDictionary(context, englishMap, R.raw.english_words_extend);
			loadDictionary(context, vietnameseMap, R.raw.vietnamese_words);
		}
	}

	public void handleVietnameseCharacter(int primaryCode,
			StringBuilder composing, int telexOrVNI, int typingLanguage) {
		int positionSign = positionSign(composing, VN_VOWELS_SIGN);
		int positonVowel = positionVowel(composing);
		int countVowels = countVowels(composing);
		if(typingLanguage == KEYBOARD_VIETNAMESE) {
			if(isSignCode(primaryCode)){
				handleSignCharacter(primaryCode, positionSign, positonVowel, countVowels, composing);
			} else {
				composing.append((char) primaryCode).toString();
			}
		} else if(typingLanguage == KEYBOARD_NO_NUMBERIC) {
			if ((char) primaryCode == 'a' || (char) primaryCode == 'e'
					|| (char) primaryCode == 'o' || (char) primaryCode == 'u'
					|| (char) primaryCode == 'i' || (char) primaryCode == 'y'
					|| (char) primaryCode == 'A' || (char) primaryCode == 'E'
					|| (char) primaryCode == 'O' || (char) primaryCode == 'U'
					|| (char) primaryCode == 'I' || (char) primaryCode == 'Y') {
				handleVowelCharacter(primaryCode, positionSign, positonVowel, countVowels, composing);
			}
			// remain
			else {
				handleRemainCharacter(primaryCode, positionSign, positonVowel, countVowels, composing);
			}
		} else {
			// 1: Handle number character
			if (primaryCode >= 48 && primaryCode <= 57) {
				if(telexOrVNI == INPUT_METHOD_AUTO || telexOrVNI == INPUT_METHOD_VNI) {
					handleNumberCharacter(primaryCode, positionSign, positonVowel, countVowels, composing);
				} else {
					composing.append((char) primaryCode).toString();
				}		
			}
			// Handle vowels & consonant
			else {
				// Vowels no sign
				if(telexOrVNI == INPUT_METHOD_AUTO || telexOrVNI == INPUT_METHOD_TELEX) {
					if ((char) primaryCode == 'a' || (char) primaryCode == 'e'
							|| (char) primaryCode == 'o' || (char) primaryCode == 'u'
							|| (char) primaryCode == 'i' || (char) primaryCode == 'y'
							|| (char) primaryCode == 'A' || (char) primaryCode == 'E'
							|| (char) primaryCode == 'O' || (char) primaryCode == 'U'
							|| (char) primaryCode == 'I' || (char) primaryCode == 'Y') {
						handleVowelCharacter(primaryCode, positionSign, positonVowel, countVowels, composing);
					}
					// remain
					else {
						handleRemainCharacter(primaryCode, positionSign, positonVowel, countVowels, composing);
					}
				} else {
					composing.append((char) primaryCode).toString();
				}
			}
		}
		
		// Fix sign when adding vowel
		// DK: > 2 nguyen am, co dau
		if((telexOrVNI == INPUT_METHOD_AUTO || telexOrVNI == INPUT_METHOD_TELEX) && primaryCode >= 65){
			int positionSign1 = positionSign(composing, VN_VOWELS_SIGN);
			int positonVowel1 = positionVowel(composing);
			int countVowels1 = countVowels(composing);
			if(positionSign1 > -1 && countVowels1 > 1)
				fixSignWhenAddingCharacter(composing, positionSign1, positonVowel1, countVowels1);
		}
	}

	/**
	 * Infinite position of sign in composing word
	 * 
	 * @param composing
	 * @return
	 */
	public int positionSign(StringBuilder composing, int [] VN_CHARACTER) {
		int postionSign = -1;
		for (int i = 0; i < composing.length(); i++) {
			for (int j : VN_CHARACTER) {
				if (composing.charAt(i) == (char) j)
					return i;
			}
		}
		return postionSign;
	}

	/**
	 * Check character key is vowel key
	 * 
	 * @param primaryCode
	 * @return
	 */
	public boolean isVowelCode(int primaryCode) {
		boolean checkVowel = false;
		for (int i : VN_VOWELS) {
			if (i == primaryCode) {
				checkVowel = true;
				break;
			}
		}
		return checkVowel;
	}
	
	/**
	 * Check character key is consonant key
	 * 
	 * @param primaryCode
	 * @return
	 */
	public boolean isConsonantCode(int primaryCode) {
		for (int i : CONSONANT_CHARACTERS) {
			if ((i == primaryCode) || ((i + ('a' - 'A')) == primaryCode)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Infinite postion of last vowel
	 * 
	 * @param composing
	 * @return
	 */
	public int positionVowel(StringBuilder composing) {
		int positionVowel = -1;
		for (int i = composing.length() - 1; i >= 0; i--) {
			for (int j = 0; j < VN_VOWELS.length; j++) {
				if (composing.charAt(i) == VN_VOWELS[j]) {
					return i;
				}
			}
		}
		return positionVowel;
	}

	/**
	 * Infinite postion of first vowel
	 * 
	 * @param composing
	 * @return
	 */
	public int positionVowelFirst(StringBuilder composing) {
		int positionVowel = -1;
		for (int i = 0; i < composing.length(); i++) {
			for (int j = 0; j < VN_VOWELS.length; j++) {
				if (composing.charAt(i) == VN_VOWELS[j]) {
					return i;
				}
			}
		}
		return positionVowel;
	}

	/**
	 * Infinite position of vowel in VN_VOWELS -> support adding sign with
	 * number character
	 * 
	 * @param character
	 * @return
	 */
	private int positionVowelInTable(char character) {
		int positionVowelInTable = -1;
		for (int i = 0; i < VN_VOWELS.length; i++) {
			if (character == VN_VOWELS[i]) {
				return i;
			}
		}
		return positionVowelInTable;
	}

	/**
	 * Count number of vowels in composing word
	 * 
	 * @param composing
	 * @return
	 */
	private int countVowels(StringBuilder composing) {
		int count = 0;
		for (int i = composing.length() - 1; i >= 0; i--) {
			for (int j = 0; j < VN_VOWELS.length; j++) {
				if (composing.charAt(i) == VN_VOWELS[j]) {
					count++;
					if (i - 1 >= 0
							&& !isVowelCode((int) composing.charAt(i - 1))) {
						return count;
					} else
						break;
				}
			}
		}
		return count;
	}

	public void handleNumberCharacter(int primaryCode, int positionSign, int positonVowel, int countVowels, StringBuilder composing) {
		// 1.1: Neu chua co nguyen am
		if (positonVowel == -1) {
			// 1.1.1: Da co ki tu
			if (composing.length() > 0) {
				if ((char) primaryCode == '9') {
					handleDCharacter(primaryCode, composing);
				}
				// 1.1.1.3:
				else {
					composing.append((char) primaryCode);
				}
			}
			// 1.1.2: Chua co ki tu
			else {
				composing.append((char) primaryCode);
			}
		}
		// 1.2: Neu da co nguyen am
		else {

			// 1.2.1: 1 - 5 -> ki tu dau
			if (primaryCode >= 49 && primaryCode <= 53) {
				// 1.2.1.1: Neu chua co dau
				if (positionSign == -1) {
					int positionVowelInTable = positionVowelInTable(composing
							.charAt(positonVowel));
					composing.setCharAt(positonVowel,
							(char) VN_VOWELS[positionVowelInTable + (int) primaryCode % 48]);
				}
				// 1.2.1.2: Neu co dau roi
				else {
					int positionVowelInTable = positionVowelInTable(composing
							.charAt(positionSign));
					int numberSign = positionVowelInTable % 6 + 48;
					int characterSign = VN_VOWELS[positionVowelInTable
							- positionVowelInTable % 6];
					// Bo dau -> Vi tri dau phai sua thanh ki tu ko dau + so
					if (numberSign == primaryCode) {
						composing.setCharAt(positionSign, (char) characterSign);
						composing.append((char) primaryCode);
					}
					// Sua dau
					else {
						composing.setCharAt(positionSign,
								(char) VN_VOWELS[positionVowelInTable
										- positionVowelInTable % 6
										+ primaryCode % 48]);
					}
				}
			}
			// 1.2.2: 6 â ê ô
			else if (primaryCode == 54) {
				handle6Character(primaryCode, composing);
			}
			// 1.2.3: ơ ư
			else if (primaryCode == 55) {
				handle7Character(primaryCode, composing);
			}
			// 1.2.4: ă
			else if (primaryCode == 56) {
				handle8Character(primaryCode, composing);
			}
			// 1.2.5: đ
			else if (primaryCode == 57) {
				handleDCharacter(primaryCode, composing);
			}
			// 1.2.6: 0 xoa dau
			else if (primaryCode == 48) {
				// Chua co dau
				if (positionSign == -1) {
					composing.append((char) primaryCode);
				}
				// Co dau roi
				else {
					int positionVowelInTable = positionVowelInTable(composing
							.charAt(positionSign));
					int characterSign = VN_VOWELS[positionVowelInTable
							- positionVowelInTable % 6];
					composing.setCharAt(positionSign, (char) characterSign);
				}
			}

		}

	}

	public void handleSignCharacter(int primaryCode, int positionSign, int positonVowel, int countVowels, StringBuilder composing) {
		int positionSignSymbolInTable = positionSignSymbolInTable(primaryCode);
		// 1.1: Neu chua co nguyen am
		if (positonVowel == -1) {

		}
		// 1.2: Neu da co nguyen am
		else {
			// 1.2.1.1: Neu chua co dau
			if (positionSign == -1) {
				int positionVowelInTable = positionVowelInTable(composing.charAt(positonVowel));
				composing.setCharAt(positonVowel,
								(char) VN_VOWELS[positionVowelInTable + 1 + positionSignSymbolInTable % 5]);
			}
			// 1.2.1.2: Neu co dau roi
			else {
				int positionVowelInTable = positionVowelInTable(composing.charAt(positionSign));
				int numberSign = positionVowelInTable % 6;
				int characterSign = VN_VOWELS[positionVowelInTable
						- positionVowelInTable % 6];
				// Bo dau -> Vi tri dau phai sua thanh ki tu ko dau
				if (numberSign == positionSignSymbolInTable((char) primaryCode) + 1) {
					composing.setCharAt(positionSign, (char) characterSign);
				}
				// Sua dau
				else {
					composing.setCharAt(positionSign,
							(char) VN_VOWELS[positionVowelInTable
									- positionVowelInTable % 6
									+ positionSignSymbolInTable % 5 + 1]);
				}
			}

		}
	}

	public void handleVowelCharacter(int primaryCode, int positionSign, int positonVowel, int countVowels, StringBuilder composing) {
		if (primaryCode == (int) 'a' || primaryCode == (int) 'A') {
			handleACharacter(primaryCode, positonVowel, countVowels, composing);
		} else if (primaryCode == (int) 'e' || primaryCode == (int) 'E') {
			handleECharacter(primaryCode, positonVowel, countVowels, composing);
		} else if (primaryCode == (int) 'o' || primaryCode == (int) 'O') {
			handleOCharacter(primaryCode, positonVowel, countVowels, composing);
		} else {
			composing.append((char) primaryCode);
		}
		
	}

	public void handleRemainCharacter(int primaryCode, int positionSign, int positonVowel, int countVowels, StringBuilder composing) {
		// 1.1: Neu chua co nguyen am
		if (positonVowel == -1) {
			// 1.1.1: Da co ki tu
			if (composing.length() > 0) {
				if ((char) primaryCode == 'd' || (char) primaryCode == 'D') {
					handleDCharacter(primaryCode, composing);
				} else if ((char) primaryCode == 'w') {
					composing.append('ư');
				} else if ((char) primaryCode == 'W') {
					composing.append('Ư');
				} else {
					composing.append((char) primaryCode);
				}
			}
			// 1.1.2: Chua co ki tu
			else {
				if ((char) primaryCode == 'w') {
					composing.append('ư');
				} else if ((char) primaryCode == 'W') {
					composing.append('Ư');
				} else
					composing.append((char) primaryCode);
			}
		}
		// 1.2: Neu da co nguyen am
		else {
			int positionSignInTable = positionSignInTable((char) primaryCode);
			// 1.2.1: Ki tu dau s f r x j
			if (positionSignInTable != -1) {
				// 1.2.1.1: Neu chua co dau -> xac dinh vi tri dat dau va` them
				// dau
				if (positionSign == -1) {
					int positionVowelInTable = positionVowelInTable(composing
							.charAt(positonVowel));
					composing.setCharAt(positonVowel,
							(char) VN_VOWELS[positionVowelInTable + (int) positionSignInTable % 5 + 1]);
				}
				// 1.2.1.2: Neu co dau roi
				else {
					int positionVowelInTable = positionVowelInTable(composing
							.charAt(positionSign));
					int numberSign = positionVowelInTable % 6;
					int characterSign = VN_VOWELS[positionVowelInTable
							- positionVowelInTable % 6];
					// Bo dau -> Vi tri dau phai sua thanh ki tu ko dau + so
					if (numberSign == positionSignInTable((char) primaryCode) + 1) {
						composing.setCharAt(positionSign, (char) characterSign);
						composing.append((char) primaryCode);
					}
					// Sua dau
					else {
						composing.setCharAt(positionSign,
								(char) VN_VOWELS[positionVowelInTable
										- positionVowelInTable % 6
										+ positionSignInTable % 5 + 1]);
					}
				}
			} else if ((char) primaryCode == 'z' || (char) primaryCode == 'Z') {
				handleZCharacter(primaryCode, positionSign, composing);
			} else if ((char) primaryCode == 'w' || (char) primaryCode == 'W') {
				handleWCharacter(primaryCode, positonVowel, countVowels, composing);
			} else if ((char) primaryCode == 'd' || (char) primaryCode == 'D') {
				handleDCharacter(primaryCode, composing);
			} else {
				quickFixSomeCase(primaryCode, positonVowel, countVowels,
						composing);
			}
		}
		
	}

	private void handle6Character(int six, StringBuilder composing) {
		int positonVowel = positionVowel(composing);
		int countVowels = countVowels(composing);
		boolean handled = false;

		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// a -> â
			if (positionVowelInTable >= 0 && positionVowelInTable < 6 * 2) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 12]);
				handled = true;
				break;
			}
			// ă -> â
			else if (positionVowelInTable >= 6 * 14
					&& positionVowelInTable < 6 * 16) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 2]);
				handled = true;
				break;
			}
			// e -> ê
			else if (positionVowelInTable >= 6 * 2
					&& positionVowelInTable < 6 * 4) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 14]);
				handled = true;
				break;
			}
			// o -> ô
			else if (positionVowelInTable >= 6 * 4
					&& positionVowelInTable < 6 * 6) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 14]);
				handled = true;
				break;
			}
			// ơ -> ô
			else if (positionVowelInTable >= 6 * 20
					&& positionVowelInTable < 6 * 22) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 2]);
				handled = true;
				break;
			}
			// â -> a + 6
			else if (positionVowelInTable >= 6 * 12
					&& positionVowelInTable < 6 * 14) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 12]);
				composing.append((char) six);
				handled = true;
				break;
			}
			// ê -> e + 6
			else if (positionVowelInTable >= 6 * 16
					&& positionVowelInTable < 6 * 18) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 14]);
				composing.append((char) six);
				handled = true;
				break;
			}
			// ô -> o + 6
			else if (positionVowelInTable >= 6 * 18
					&& positionVowelInTable < 6 * 20) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 14]);
				composing.append((char) six);
				handled = true;
				break;
			}
		}
		if (!handled)
			composing.append((char) six);
	}

	private void handle7Character(int seven, StringBuilder composing) {
		int positonVowel = positionVowel(composing);
		int countVowels = countVowels(composing);
		boolean handled = false;

		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// o -> ơ
			if (positionVowelInTable >= 6 * 4 && positionVowelInTable < 6 * 6) {
				// uo -> ươ
				if (i - 1 >= 0) {
					int positionVowelInTable1 = positionVowelInTable(composing
							.charAt(i - 1));
					if (positionVowelInTable1 >= 6 * 6
							&& positionVowelInTable1 < 6 * 8) {
						// TH uo -> uơ
						if (i - 2 >= 0
								&& (composing.charAt(i - 2) == 'h' || composing
										.charAt(i - 2) == 'H')
								&& positonVowel == composing.length() - 1) {

						} else
							composing
									.setCharAt(
											i - 1,
											(char) VN_VOWELS[positionVowelInTable1 + 6 * 16]);
					}
				}
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 16]);
				handled = true;
				break;
			}
			// ô -> ơ
			else if (positionVowelInTable >= 6 * 18
					&& positionVowelInTable < 6 * 20) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 2]);
				handled = true;
				break;
			}
			// u -> ư
			else if (positionVowelInTable >= 6 * 6
					&& positionVowelInTable < 6 * 8) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 16]);
				handled = true;
				break;
			}
			// ơ -> o + 7
			else if (positionVowelInTable >= 6 * 20
					&& positionVowelInTable < 6 * 22) {
				// ươ -> uo
				if (i - 1 >= 0) {
					int positionVowelInTable1 = positionVowelInTable(composing
							.charAt(i - 1));
					if (positionVowelInTable1 >= 6 * 22
							&& positionVowelInTable1 < 6 * 24) {
						composing
								.setCharAt(
										i - 1,
										(char) VN_VOWELS[positionVowelInTable1 - 6 * 16]);
					}
				}
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 16]);
				handled = true;
				composing.append((char) seven);
				break;
			}
			// ư -> u + 7
			else if (positionVowelInTable >= 6 * 22
					&& positionVowelInTable < 6 * 24) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 16]);
				composing.append((char) seven);
				handled = true;
				break;
			}
		}
		if (!handled)
			composing.append((char) seven);
	}

	private void handle8Character(int eight, StringBuilder composing) {
		int positonVowel = positionVowel(composing);
		int countVowels = countVowels(composing);
		boolean handled = false;

		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// a -> ă
			if (positionVowelInTable >= 0 && positionVowelInTable < 6 * 2) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 14]);
				handled = true;
				break;
			}
			// â -> ă
			else if (positionVowelInTable >= 6 * 12
					&& positionVowelInTable < 6 * 14) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 2]);
				handled = true;
				break;
			}
			// ă -> a + 8
			else if (positionVowelInTable >= 6 * 14
					&& positionVowelInTable < 6 * 16) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 14]);
				composing.append((char) eight);
				handled = true;
				break;
			}
		}
		if (!handled)
			composing.append((char) eight);
	}

	private void handleDCharacter(int nine, StringBuilder composing) {
		// 1.2.5.1: Truong hop d
		if (composing.charAt(0) == 'd') {
			composing.setCharAt(0, 'đ');
		}
		// 1.2.5.2: Truong hop D
		else if (composing.charAt(0) == 'D') {
			composing.setCharAt(0, 'Đ');
		}
		// 1.2.5.3: Truong hop d
		else if (composing.charAt(0) == 'đ') {
			composing.setCharAt(0, 'd');
			composing.append((char) nine);
		}
		// 1.2.5.4: Truong hop D
		else if (composing.charAt(0) == 'Đ') {
			composing.setCharAt(0, 'D');
			composing.append((char) nine);
		}
		// 1.2.5.3:
		else {
			composing.append((char) nine);
		}
	}

	private void handleACharacter(int a, int positonVowel, int countVowels, StringBuilder composing) {
		boolean handled = false;

		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// a -> â
			if (positionVowelInTable >= 0 && positionVowelInTable < 6 * 2) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 12]);
				handled = true;
				break;
			}
			// ă -> â
			else if (positionVowelInTable >= 6 * 14
					&& positionVowelInTable < 6 * 16) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 2]);
				handled = true;
				break;
			}
			// â -> a + a
			else if (positionVowelInTable >= 6 * 12
					&& positionVowelInTable < 6 * 14) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 12]);
				composing.append((char) a);
				handled = true;
				break;
			}
		}
		if (!handled) {
			composing.append((char) a);
		}
	}

	private void handleECharacter(int e, int positonVowel, int countVowels, StringBuilder composing) {
		boolean handled = false;

		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// e -> ê
			if (positionVowelInTable >= 6 * 2 && positionVowelInTable < 6 * 4) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 14]);
				handled = true;
				break;
			}
			// ê -> e + e
			else if (positionVowelInTable >= 6 * 16
					&& positionVowelInTable < 6 * 18) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 14]);
				composing.append((char) e);
				handled = true;
				break;
			}
		}
		if (!handled)
			composing.append((char) e);
	}

	private void handleOCharacter(int o, int positonVowel, int countVowels, StringBuilder composing) {
		boolean handled = false;

		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// o -> ô
			if (positionVowelInTable >= 6 * 4 && positionVowelInTable < 6 * 6) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 14]);
				handled = true;
				break;
			}
			// ơ -> ô
			else if (positionVowelInTable >= 6 * 20
					&& positionVowelInTable < 6 * 22) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 2]);
				handled = true;
				break;
			}
			// ô -> o + o
			else if (positionVowelInTable >= 6 * 18
					&& positionVowelInTable < 6 * 20) {
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable - 6 * 14]);
				composing.append((char) o);
				handled = true;
				break;
			}
		}
		if (!handled)
			composing.append((char) o);
	}

	private void handleZCharacter(int primaryCode, int positionSign,
			StringBuilder composing) {
		// Sign unavailable
		if (positionSign == -1) {
			composing.append((char) primaryCode);
		}
		// Sign available
		else {
			int positionVowelInTable = positionVowelInTable(composing
					.charAt(positionSign));
			int characterSign = VN_VOWELS[positionVowelInTable
					- positionVowelInTable % 6];
			composing.setCharAt(positionSign, (char) characterSign);
		}
	}

	private void handleWCharacter(int w, int positonVowel, int countVowels, StringBuilder composing) {
		boolean handled = false;
	
		for (int i = positonVowel; i >= positonVowel + 1 - countVowels; i--) {
			int positionVowelInTable = positionVowelInTable(composing.charAt(i));
			// a -> ă
			if (positionVowelInTable >= 0 && positionVowelInTable < 6 * 2) {
				handled = true;
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable + 6 * 14]);
				if (i - 1 >= 0) {
					int positionVowelInTable1 = positionVowelInTable(composing
							.charAt(i - 1));
					//ua -> ưa
					if (positionVowelInTable1 >= 6 * 6 && positionVowelInTable1 < 6 * 8) {
						composing.setCharAt(i - 1, (char) VN_VOWELS[positionVowelInTable1 + 6 * 16]);
						composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable]);
						break;
					}
					//ưa -> uaw
					else if(positionVowelInTable1 >= 6 * 22 && positionVowelInTable1 < 6 * 24){
						composing.setCharAt(i - 1, (char) VN_VOWELS[positionVowelInTable1 - 6 * 16]);
						composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable]);
						handled = false;
						break;
					}
				}
				break;
			}
			// o -> ơ
			else if (positionVowelInTable >= 6 * 4 && positionVowelInTable < 6 * 6) {
				// uo -> ươ
				if (i - 1 >= 0) {
					int positionVowelInTable1 = positionVowelInTable(composing.charAt(i - 1));
					if (positionVowelInTable1 >= 6 * 6
							&& positionVowelInTable1 < 6 * 8) {
						// TH uo -> uơ
						if (i - 2 >= 0 && (composing.charAt(i - 2) == 'h' || composing.charAt(i - 2) == 'H')
								&& positonVowel == composing.length() - 1) {
							
						} else
							composing.setCharAt(i - 1, (char) VN_VOWELS[positionVowelInTable1 + 6 * 16]);
					}
				}
				composing.setCharAt(i,
						(char) VN_VOWELS[positionVowelInTable + 6 * 16]);
				handled = true;
				break;
			}
			// â -> ă
			else if (positionVowelInTable >= 6 * 12
					&& positionVowelInTable < 6 * 14) {
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable + 6 * 2]);
				handled = true;
				break;
			}
			// ô -> ơ
			else if (positionVowelInTable >= 6 * 18
					&& positionVowelInTable < 6 * 20) {
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable + 6 * 2]);
				handled = true;
				break;
			}
			// u -> ư
			else if (positionVowelInTable >= 6 * 6 && positionVowelInTable < 6 * 8) {
				handled = true;
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable + 6 * 16]);
				if (i - 1 >= 0) {
					int positionVowelInTable1 = positionVowelInTable(composing
							.charAt(i - 1));
					//uu -> ưu
					if (positionVowelInTable1 >= 6 * 6 && positionVowelInTable1 < 6 * 8) {
						composing.setCharAt(i - 1, (char) VN_VOWELS[positionVowelInTable1 + 6 * 16]);
						composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable]);
						break;
					}
					//ưu -> uuw
					else if(positionVowelInTable1 >= 6 * 22 && positionVowelInTable1 < 6 * 24){
						composing.setCharAt(i - 1, (char) VN_VOWELS[positionVowelInTable1 - 6 * 16]);
						composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable]);
						handled = false;
						break;
					}
				}
				break;
			}
			// ă -> a + 8
			else if (positionVowelInTable >= 6 * 14 && positionVowelInTable < 6 * 16) {
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable - 6 * 14]);
				composing.append((char) w);
				handled = true;
				break;
			}
			// ơ -> o + w
			else if (positionVowelInTable >= 6 * 20 && positionVowelInTable < 6 * 22) {
				// ươ -> uo
				if (i - 1 >= 0) {
					int positionVowelInTable1 = positionVowelInTable(composing.charAt(i - 1));
					if (positionVowelInTable1 >= 6 * 22 && positionVowelInTable1 < 6 * 24) {
						composing.setCharAt(i - 1, (char) VN_VOWELS[positionVowelInTable1 - 6 * 16]);
					}
				}
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable - 6 * 16]);
				handled = true;
				composing.append((char) w);
				break;
			}
			// ư -> u + w
			else if (positionVowelInTable >= 6 * 22 && positionVowelInTable < 6 * 24) {
				composing.setCharAt(i, (char) VN_VOWELS[positionVowelInTable - 6 * 16]);
				composing.append((char) w);
				handled = true;
				break;
			}
		}
		if (!handled)
			composing.append((char) w);
	}

	private void quickFixSomeCase(int primaryCode, int positonVowel,
			int countVowels, StringBuilder composing) {
		// Fix ưo, uơ -> ươ
		if (countVowels == 2) {
			if(composing.toString().toLowerCase().contains("uơ")){
				if (composing.charAt(positonVowel - 1) == 'U')
					composing.setCharAt(positonVowel - 1, 'Ư');
				else
					composing.setCharAt(positonVowel - 1, 'ư');
			}else if(composing.toString().toLowerCase().contains("ưo")){
				if (composing.charAt(positonVowel) == 'O')
					composing.setCharAt(positonVowel, 'Ơ');
				else
					composing.setCharAt(positonVowel, 'ơ');
			}
		}
		composing.append((char) primaryCode);
	}

	/**
	 * Infinite position of sign in VN_CONSONANTS_SIGN -> support back to number
	 * of sign
	 * 
	 * @param character
	 * @return
	 */
	private int positionSignInTable(char character) {
		int positionSignInTable = -1;
		for (int i = 0; i < VN_CONSONANTS_SIGN.length; i++) {
			if (character == VN_CONSONANTS_SIGN[i]) {
				return i;
			}
		}
		return positionSignInTable;
	}

	/**
	 * Check input key is sign key
	 * 
	 * @param primaryCode
	 * @return
	 */
	public boolean isSignCode(int primaryCode) {
		boolean checkSign = false;
		for (int i : mWordSign) {
			if (i == primaryCode) {
				checkSign = true;
				break;
			}
		}
		return checkSign;
	}

	/**
	 * 
	 * @param primaryCode
	 * @return
	 */
	private int positionSignSymbolInTable(int primaryCode) {
		int positionSignSymbolInTable = -1;
		for (int i = 0; i < mWordSign.length; i++) {
			if (primaryCode == mWordSign[i]) {
				return i;
			}
		}
		return positionSignSymbolInTable;
	}

	/**
	 * Ham xac dinh nguyen am duoc dien dau cach nguyen am cuoi la bao nhieu Mac
	 * dinh dau la nguyen am cuoi, tru cac truong hop dac biet
	 * 
	 * @param positonVowel
	 * @param countVowels
	 * @return
	 */
	private int infiniteBufPosition(int positonVowel, int countVowels,
			StringBuilder composing) {
		int bufPosition = 0;
		// 1.2.1.1.1: Neu chi co 1 nguyen am

		// 1.2.1.1.2: Neu co 2 nguyen am
		if (countVowels == 2) {
			// Nguyen am cuoi
			if (positonVowel == composing.length() - 1) {
				// Loai tru uơ, qu, gi
				if (composing.toString().toLowerCase().lastIndexOf("uơ") > -1
						|| composing.toString().toLowerCase().lastIndexOf("uê") > -1
						|| composing.toString().toLowerCase().lastIndexOf("qu") > -1
						|| composing.toString().toLowerCase().lastIndexOf("gi") > -1) {

				} else
					bufPosition = 1;
			}
		}
		// 1.2.1.1.3: Neu co 3 nguyen am
		else if (countVowels == 3) {
			// Loai tru uyê
			if (composing.toString().toLowerCase().lastIndexOf("uyê") > -1
					|| (composing.toString().toLowerCase().lastIndexOf("gi") > -1
							&& isConsonantCode((int)composing.charAt(composing.length() - 1)))) {

			} else
				bufPosition = 1;
		}
		return bufPosition;
	}

	/**
	 * Vietnamese -> Vietnamese no sign
	 * 
	 * @param str
	 * @return
	 */
	private String removeSignVietnamese(String str) {
		String temp = Normalizer.normalize(str, Normalizer.Form.NFD);
		Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
		return pattern.matcher(temp).replaceAll("").replaceAll("Đ", "D")
				.replace("đ", "d");

	}

	/**
	 * Load dictionary from txt
	 * 
	 * @param words
	 * @param resourceId
	 */
	private void loadDictionary(Context context, HashMap<String, Integer> words,
			int resourceId) {
		// The InputStream opens the resourceId and sends it to the buffer
		InputStream is = context.getResources().openRawResource(resourceId);
		InputStreamReader inputreader = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(inputreader);
		String readLine = null;

		try {
			int count = 0;
			// While the BufferedReader readLine is not null
			while ((readLine = br.readLine()) != null) {
				words.put(readLine, Integer.valueOf(count));
				count++;
			}
			
			// Close the InputStream and BufferedReader
			br.close();
			inputreader.close();
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean autoTransformViEn(StringBuilder composing,
			StringBuilder composingNormal, boolean englishMode, int type) {
		
		checkEnglishEqual = englishMap.containsKey(composingNormal.toString().toLowerCase());
		checkVietnameseEqual = vietnameseMap.containsKey(composing.toString().toLowerCase());
		boolean noVietnameseWord = !isVietnameseWord(composing) || !simpleCheckVietnamese(composing);
		
		boolean chooseComposing = chooseComposing(noVietnameseWord, checkVietnameseEqual, 
				checkEnglishEqual, composing.length(), composingNormal.length(), type, englishMode);
		
		return chooseComposing;
	}
	
	private void fixSignWhenAddingCharacter(StringBuilder composing, int positionSign, 
			int positonVowel, int countVowels){
		int positionVowelInTable = positionVowelInTable(composing
				.charAt(positionSign));
		int numberSign = positionVowelInTable % 6;
		int characterSign = VN_VOWELS[positionVowelInTable
				- positionVowelInTable % 6];
		// Remove sign
		composing.setCharAt(positionSign, (char) characterSign);
		
		// Add sign
		int bufPosition = infiniteBufPosition(positonVowel,
				countVowels, composing);
		for (int i = 0; i < VN_VOWELS.length; i++) {
			if (composing.charAt(positonVowel - bufPosition) == VN_VOWELS[i]) {
				composing.setCharAt(positonVowel - bufPosition,
								(char) VN_VOWELS[i + numberSign]);
				break;
			}
		}
	}
	
	/**
	 * Handle delete vietnamese character
	 * Delete sign when backspace at vowel with sign
	 * @param composing
	 * @param length
	 * @return
	 */
	public String handleDeleteCharacter(StringBuilder composing, int length){
		//Neu la tu tieng viet, den vi tri dau, xoa dau
		//Neu khong co' dau nhung do dai be' hon, giu nguyen
		int positionSign = positionSign(composing, VN_VOWELS_SIGN);
		if(positionSign == length -1){
			int positionVowelInTable = positionVowelInTable(composing
					.charAt(positionSign));
			int characterSign = VN_VOWELS[positionVowelInTable
			              				- positionVowelInTable % 6];
			composing.setCharAt(positionSign, (char) characterSign);
		} else{
			composing.delete(length - 1, length);
		}
		return composing.toString();
	}
	
	private boolean chooseComposing(boolean noVietnameseWord, boolean checkVietnameseEqual, 
			boolean checkEnglishEqual, int composingLen, int composingNormalLen, int type, boolean englishMode){
		boolean chooseComposing = true;
		
		// User data
		if (type != -1) {
            if (type == 1) {
                chooseComposing = false;
            }
	    }
		// Auto check
		else{
			if (englishMode) {
				if(checkEnglishEqual){
					chooseComposing = false;
				}
				else if(!checkEnglishEqual && checkVietnameseEqual){
					chooseComposing = true;
				}
				else{
					chooseComposing = false;
				}
			} else {
				if(noVietnameseWord){
					chooseComposing = false;
				}
				else if(checkVietnameseEqual){
					chooseComposing = true;
				}
				else if(!checkVietnameseEqual && checkEnglishEqual){
					chooseComposing = false;
				}
				else{
					if(composingNormalLen > composingLen + 2)
						chooseComposing = false;
					else
						chooseComposing = true;
				}
			}
		}
		
		return chooseComposing;
	}
	
	public static boolean isVietnameseWord(CharSequence word) {
    	for (int i = word.length() - 1; i >= 0; i--) {
    		int currentChar = word.charAt(i);
    		for (int j = 0; j < NON_VIETNAMESE_CHARACTERS.length; j++) {
    			if (currentChar == NON_VIETNAMESE_CHARACTERS[j][0] || 
    				currentChar == NON_VIETNAMESE_CHARACTERS[j][0] + ('a' - 'A')) {
    				if (i >= NON_VIETNAMESE_CHARACTERS[j][1]) {
    					return false;
    				}
    			}			
    		}
    	}
    	return true;
    }
	
	private boolean simpleCheckVietnamese(StringBuilder composing){
		int positionVowelFirst = positionVowelFirst(composing);
		int positionVowelLast = positionVowel(composing);
		
		if(positionVowelFirst > -1 && positionVowelLast > positionVowelFirst){
			for(int i = positionVowelFirst; i <= positionVowelLast; i++){
				if(isConsonantCode((int) composing.charAt(i))){
					return false;
				}
			}
		}
		return true;
	}

	public int handleAutoDetectTelexVni(StringBuilder composing, StringBuilder composingNormal){
		int VNIorTELEX = 0;
		int positionOfSign = positionSign(composing, VN_VOWELS_SIGN_FULL);
		if(positionOfSign > -1) {
			for(int i = 0; i < composingNormal.length(); i++){
				if(composingNormal.charAt(i) >= 48 && composingNormal.charAt(i) <= 57){
					return INPUT_METHOD_VNI;
				}
			}
			if(VNIorTELEX != INPUT_METHOD_VNI) {
				return INPUT_METHOD_TELEX;
			}
		}
		return VNIorTELEX;
	}
	
	/**
	 * Generate getter and setter to get value of check english and vietnamese
	 * @return
	 */
	public boolean getCheckEnglish() {
		return checkEnglishEqual;
	}

	public boolean getCheckVietnamese() {
		return checkVietnameseEqual;
	}

	private static final int[] VN_VOWELS = { 'a', 'á', 'à', 'ả', 'ã', 'ạ', // 0
			'A', 'Á', 'À', 'Ả', 'Ã', 'Ạ', // 1

			'e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ', // 2
			'E', 'É', 'È', 'Ẻ', 'Ẽ', 'Ẹ', // 3

			'o', 'ó', 'ò', 'ỏ', 'õ', 'ọ', // 4
			'O', 'Ó', 'Ò', 'Ỏ', 'Õ', 'Ọ', // 5

			'u', 'ú', 'ù', 'ủ', 'ũ', 'ụ', // 6
			'U', 'Ú', 'Ù', 'Ủ', 'Ũ', 'Ụ', // 7

			'i', 'í', 'ì', 'ỉ', 'ĩ', 'ị', // 8
			'I', 'Í', 'Ì', 'Ỉ', 'Ĩ', 'Ị', // 9

			'y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ', // 10
			'Y', 'Ý', 'Ỳ', 'Ỷ', 'Ỹ', 'Ỵ', // 11

			'â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ', // 12
			'Â', 'Ấ', 'Ầ', 'Ẩ', 'Ẫ', 'Ậ', // 13

			'ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ', // 14
			'Ă', 'Ắ', 'Ằ', 'Ẳ', 'Ẵ', 'Ặ', // 15

			'ê', 'ế', 'ề', 'ể', 'ễ', 'ệ', // 16
			'Ê', 'Ế', 'Ề', 'Ể', 'Ễ', 'Ệ', // 17

			'ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ', // 18
			'Ô', 'Ố', 'Ồ', 'Ổ', 'Ỗ', 'Ộ', // 19

			'ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ', // 20
			'Ơ', 'Ớ', 'Ờ', 'Ở', 'Ỡ', 'Ợ', // 21

			'ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự', // 22
			'Ư', 'Ứ', 'Ừ', 'Ử', 'Ữ', 'Ự' // 23
	};

	public final int[] VN_VOWELS_SIGN = { 'á', 'à', 'ả', 'ã', 'ạ', 'Á',
			'À', 'Ả', 'Ã', 'Ạ',

			'é', 'è', 'ẻ', 'ẽ', 'ẹ', 'É', 'È', 'Ẻ', 'Ẽ', 'Ẹ',

			'ó', 'ò', 'ỏ', 'õ', 'ọ', 'Ó', 'Ò', 'Ỏ', 'Õ', 'Ọ',

			'ú', 'ù', 'ủ', 'ũ', 'ụ', 'Ú', 'Ù', 'Ủ', 'Ũ', 'Ụ',

			'í', 'ì', 'ỉ', 'ĩ', 'ị', 'Í', 'Ì', 'Ỉ', 'Ĩ', 'Ị',

			'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ', 'Ý', 'Ỳ', 'Ỷ', 'Ỹ', 'Ỵ',

			'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ', 'Ấ', 'Ầ', 'Ẩ', 'Ẫ', 'Ậ',

			'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ', 'Ắ', 'Ằ', 'Ẳ', 'Ẵ', 'Ặ',

			'ế', 'ề', 'ể', 'ễ', 'ệ', 'Ế', 'Ề', 'Ể', 'Ễ', 'Ệ',

			'ố', 'ồ', 'ổ', 'ỗ', 'ộ', 'Ố', 'Ồ', 'Ổ', 'Ỗ', 'Ộ',

			'ớ', 'ờ', 'ở', 'ỡ', 'ợ', 'Ớ', 'Ờ', 'Ở', 'Ỡ', 'Ợ',

			'ứ', 'ừ', 'ử', 'ữ', 'ự', 'Ứ', 'Ừ', 'Ử', 'Ữ', 'Ự', };
	
	public static final int[] VN_VOWELS_SIGN_FULL = { 
		'á', 'à', 'ả', 'ã', 'ạ', 'Á', 'À', 'Ả', 'Ã', 'Ạ',

		'é', 'è', 'ẻ', 'ẽ', 'ẹ', 'É', 'È', 'Ẻ', 'Ẽ', 'Ẹ',

		'ó', 'ò', 'ỏ', 'õ', 'ọ', 'Ó', 'Ò', 'Ỏ', 'Õ', 'Ọ',

		'ú', 'ù', 'ủ', 'ũ', 'ụ', 'Ú', 'Ù', 'Ủ', 'Ũ', 'Ụ',

		'í', 'ì', 'ỉ', 'ĩ', 'ị', 'Í', 'Ì', 'Ỉ', 'Ĩ', 'Ị',

		'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ', 'Ý', 'Ỳ', 'Ỷ', 'Ỹ', 'Ỵ',

		'â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ', 'Â', 'Ấ', 'Ầ', 'Ẩ', 'Ẫ', 'Ậ', 
		
		'ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ', 'Ă', 'Ắ', 'Ằ', 'Ẳ', 'Ẵ', 'Ặ',

		'ê', 'ế', 'ề', 'ể', 'ễ', 'ệ', 'Ê', 'Ế', 'Ề', 'Ể', 'Ễ', 'Ệ',

		'ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ', 'Ô', 'Ố', 'Ồ', 'Ổ', 'Ỗ', 'Ộ',

		'ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ', 'Ơ', 'Ớ', 'Ờ', 'Ở', 'Ỡ', 'Ợ',

		'ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự', 'Ư', 'Ứ', 'Ừ', 'Ử', 'Ữ', 'Ự',  };

	private static final int[] VN_CONSONANTS_SIGN = { 's', 'f', 'r', 'x', 'j',
			'S', 'F', 'R', 'X', 'J' };

	private static final int[] mWordSign = { 0x0301, 0x0300, 0x0309, 0x0303,
			0x0323 }; // sac huyen hoi nga nang
	
	private static final int[] CONSONANT_CHARACTERS = {'B', 'C', 'D', 'Đ', 'F', 'G', 'H', 'J', 'K', 'L',
		'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Z'};
	
	private static final int[][] NON_VIETNAMESE_CHARACTERS = {
    	{'B', 1}, {'D', 1}, {'F', 0}, {'J', 0}, {'K', 1}, {'L', 1}, {'Q', 1}, 
    	{'R', 2}, {'S', 1}, {'V', 1}, {'W', 0}, {'X', 1}, {'Z', 0}
    };
}
