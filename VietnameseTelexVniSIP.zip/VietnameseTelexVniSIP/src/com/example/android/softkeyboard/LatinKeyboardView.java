/*
 * Copyright (C) 2008-2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.softkeyboard;

import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.Keyboard.Key;
import android.inputmethodservice.KeyboardView;
import android.preference.PreferenceManager;
import android.util.AttributeSet;
import android.view.inputmethod.InputMethodSubtype;

@SuppressLint("NewApi")
public class LatinKeyboardView extends KeyboardView {

    static final int KEYCODE_OPTIONS = -100;
    private Context mContext;
    private int mStyleKeyboard;
    
    public LatinKeyboardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
    }

    public LatinKeyboardView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected boolean onLongPress(Key key) {

        if (key.codes[0] == Keyboard.KEYCODE_CANCEL) {
            getOnKeyboardActionListener().onKey(KEYCODE_OPTIONS, null);
            return true;
        } else if (key.codes[0] == Keyboard.KEYCODE_DELETE) {
        	((SoftKeyboard)mContext).handleLongClickBackspace();
            return false;
        } else if (key.codes[0] == 10) {
        	((SoftKeyboard)mContext).handleLongClickDone();
            return false;
        } else if (key.codes[0] == 48) {
        	boolean isPhoneInput = PreferenceManager.getDefaultSharedPreferences(
    				mContext).getBoolean("IS_PHONE_INPUT",false);
        	if(isPhoneInput) {
        		getOnKeyboardActionListener().onKey(43, null);
        	} else {
        		getOnKeyboardActionListener().onKey(41, null);
        	}
        	return true;
        } else if (key.codes[0] == 49) {
        	getOnKeyboardActionListener().onKey(33, null);
        	return true; 
        } else if (key.codes[0] == 50) {
        	getOnKeyboardActionListener().onKey(64, null);
        	return true; 
        } 
        else if (key.codes[0] == 51) {
        	getOnKeyboardActionListener().onKey(35, null);
        	return true; 
        } 
        else if (key.codes[0] == 52) {
        	getOnKeyboardActionListener().onKey(36, null);
        	return true; 
        } 
        else if (key.codes[0] == 53) {
        	getOnKeyboardActionListener().onKey(37, null);
        	return true; 
        } 
        else if (key.codes[0] == 54) {
        	getOnKeyboardActionListener().onKey(94, null);
        	return true; 
        } 
        else if (key.codes[0] == 55) {
        	getOnKeyboardActionListener().onKey(38, null);
        	return true; 
        } 
        else if (key.codes[0] == 56) {
        	getOnKeyboardActionListener().onKey(42, null);
        	return true; 
        } 
        else if (key.codes[0] == 57) {
        	getOnKeyboardActionListener().onKey(40, null);
        	return true; 
        } else if (key.codes[0] == 113) {
        	getOnKeyboardActionListener().onKey(49, null);
        	return true; 
        } else if (key.codes[0] == 119) {
        	getOnKeyboardActionListener().onKey(50, null);
        	return true; 
        } else if (key.codes[0] == 101) {
        	getOnKeyboardActionListener().onKey(51, null);
        	return true; 
        } else if (key.codes[0] == 114) {
        	getOnKeyboardActionListener().onKey(52, null);
        	return true; 
        } else if (key.codes[0] == 116) {
        	getOnKeyboardActionListener().onKey(53, null);
        	return true; 
        } else if (key.codes[0] == 121) {
        	getOnKeyboardActionListener().onKey(54, null);
        	return true; 
        } else if (key.codes[0] == 117) {
        	getOnKeyboardActionListener().onKey(55, null);
        	return true; 
        } else if (key.codes[0] == 105) {
        	getOnKeyboardActionListener().onKey(56, null);
        	return true; 
        } else if (key.codes[0] == 111) {
        	getOnKeyboardActionListener().onKey(57, null);
        	return true; 
        } else if (key.codes[0] == 112) {
        	getOnKeyboardActionListener().onKey(48, null);
        	return true; 
        } else if (key.codes[0] == 0x0103) {
        	getOnKeyboardActionListener().onKey(49, null);
        	return true; 
        } else if (key.codes[0] == 0x00E2) {
        	getOnKeyboardActionListener().onKey(50, null);
        	return true; 
        } else if (key.codes[0] == 0x0111) {
        	getOnKeyboardActionListener().onKey(51, null);
        	return true; 
        } else if (key.codes[0] == 0x00EA) {
        	getOnKeyboardActionListener().onKey(52, null);
        	return true; 
        } else if (key.codes[0] == 0x01B0) {
        	getOnKeyboardActionListener().onKey(53, null);
        	return true; 
        } else if (key.codes[0] == 0x0301) {
        	getOnKeyboardActionListener().onKey(54, null);
        	return true; 
        } else if (key.codes[0] == 0x0300) {
        	getOnKeyboardActionListener().onKey(55, null);
        	return true; 
        } else if (key.codes[0] == 0x0309) {
        	getOnKeyboardActionListener().onKey(56, null);
        	return true; 
        } else if (key.codes[0] == 0x0303) {
        	getOnKeyboardActionListener().onKey(57, null);
        	return true; 
        } else if (key.codes[0] == 0x0323) {
        	getOnKeyboardActionListener().onKey(48, null);
        	return true; 
        } else {
            return super.onLongPress(key);
        }
    }

    void setSubtypeOnSpaceKey(final InputMethodSubtype subtype) {
        final LatinKeyboard keyboard = (LatinKeyboard)getKeyboard();
        keyboard.setSpaceIcon(getResources().getDrawable(subtype.getIconResId()));
        invalidateAllKeys();
    }
	
	@Override
	public void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);

		mStyleKeyboard = PreferenceManager.getDefaultSharedPreferences(
				mContext).getInt("STYLE_KEYBOARD",
				R.layout.input_nomal);
		boolean isPhoneInput = PreferenceManager.getDefaultSharedPreferences(
				mContext).getBoolean("IS_PHONE_INPUT",false);
		List<Key> keys = getKeyboard().getKeys();
		if(!isPhoneInput) {
	        for (Key key : keys) {
	            if (key.codes[0] <= 32) {
	            	
	                Drawable npd
	                    = (Drawable) mContext.getResources().getDrawable(R.drawable.key_normal);
	                npd.setBounds(key.x, key.y, key.x + key.width, key.y + key.height);
	        		
	                if(mStyleKeyboard == 0){
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 2){
	        			npd.setColorFilter(Color.parseColor("#990066"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 3){
	        			npd.setColorFilter(Color.parseColor("#551A8B"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 4){
	        			npd.setColorFilter(Color.parseColor("#000000"), Mode.MULTIPLY);
	        		}else{
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}
	                npd.draw(canvas);
	            } 
	            if (key.codes[0] == 46 || key.codes[0] == 44 ) {
	            	
	            	Drawable npd
	                = (Drawable) mContext.getResources().getDrawable(R.drawable.key_normal);
		            npd.setBounds(key.x, key.y, key.x + key.width, key.y + key.height);
	
		            if(mStyleKeyboard == 0){
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 2){
	        			npd.setColorFilter(Color.parseColor("#990066"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 3){
	        			npd.setColorFilter(Color.parseColor("#551A8B"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 4){
	        			npd.setColorFilter(Color.parseColor("#000000"), Mode.MULTIPLY);
	        		}else{
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}
		            npd.draw(canvas);
	            }
	            
	            if (key.codes[0] >= 48 && key.codes[0] <=57 ) {
	            	
	            	Drawable npd
	                = (Drawable) mContext.getResources().getDrawable(R.drawable.key_normal);
		            npd.setBounds(key.x, key.y, key.x + key.width, key.y + key.height);
		            
	        		if(mStyleKeyboard == 0){
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 2){
	        			npd.setColorFilter(Color.parseColor("#990066"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 3){
	        			npd.setColorFilter(Color.parseColor("#551A8B"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 4){
	        			npd.setColorFilter(Color.parseColor("#000000"), Mode.MULTIPLY);
	        		}else{
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}
		            npd.draw(canvas);

	            }
	            
	            Paint paint = new Paint();
	            paint.setTextAlign(Align.RIGHT);
	            paint.setTextSize(mContext.getResources().getDimensionPixelSize(R.dimen.popup_character_size));
	            paint.setColor(Color.parseColor("#8B1A1A"));
	   
	            if (key.label != null) {
	            	if(key.codes[0] > 32){
	            		
	            		String sub = "";
	            		int popupAlign = mContext.getResources().getDimensionPixelSize(R.dimen.popup_character_align);
	            		try {
	            			sub = key.popupCharacters.toString().substring(0, 1);
						} catch (Exception e) {
							// TODO: handle exception
						}
		                canvas.drawText(sub, key.x + key.width - popupAlign,
		                                key.y + key.height - popupAlign, paint);
		                key.popupCharacters = sub;
	            	}
	            } 
	        }
		} else {
			Paint paint = new Paint();
            paint.setTextAlign(Align.RIGHT);
            paint.setTextSize(mContext.getResources().getDimensionPixelSize(R.dimen.popup_character_size));
            paint.setColor(Color.parseColor("#8B1A1A"));
            for (Key key : keys) {
	            if (key.label != null) {
	            	if(key.codes[0] >= 48 && key.codes[0] <= 57){
	            		
	            		String sub = "";
	            		int popupAlign = mContext.getResources().getDimensionPixelSize(R.dimen.popup_character_align);
	            		try {
	            			sub = key.popupCharacters.toString();
						} catch (Exception e) {
							// TODO: handle exception
						}
		                canvas.drawText(sub, key.x + key.width - popupAlign,
		                                key.y + key.height - popupAlign, paint);
		                key.popupCharacters = sub;
	            	} else {
	            		Drawable npd
		                = (Drawable) mContext.getResources().getDrawable(R.drawable.key_normal);
			            npd.setBounds(key.x, key.y, key.x + key.width, key.y + key.height);
			            
		        		if(mStyleKeyboard == 0){
		        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
		        		}else if(mStyleKeyboard == 2){
		        			npd.setColorFilter(Color.parseColor("#990066"), Mode.MULTIPLY);
		        		}else if(mStyleKeyboard == 3){
		        			npd.setColorFilter(Color.parseColor("#551A8B"), Mode.MULTIPLY);
		        		}else if(mStyleKeyboard == 4){
		        			npd.setColorFilter(Color.parseColor("#000000"), Mode.MULTIPLY);
		        		}else{
		        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
		        		}
			            npd.draw(canvas);
		
	            	}
	            } else {

            		Drawable npd
	                = (Drawable) mContext.getResources().getDrawable(R.drawable.key_normal);
		            npd.setBounds(key.x, key.y, key.x + key.width, key.y + key.height);
		            
	        		if(mStyleKeyboard == 0){
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 2){
	        			npd.setColorFilter(Color.parseColor("#990066"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 3){
	        			npd.setColorFilter(Color.parseColor("#551A8B"), Mode.MULTIPLY);
	        		}else if(mStyleKeyboard == 4){
	        			npd.setColorFilter(Color.parseColor("#000000"), Mode.MULTIPLY);
	        		}else{
	        			npd.setColorFilter(Color.parseColor("#000011"), Mode.MULTIPLY);
	        		}
		            npd.draw(canvas);
	            }
            }
		}
	}
}
