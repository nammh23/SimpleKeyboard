package com.example.android.softkeyboard;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.android.adapter.StyleKeyboardAdapter;
import com.example.android.softkeyboard.intro.ImeUtils;
import com.example.android.softkeyboard.intro.IntroActivity;
import com.example.android.softkeyboard.sqlitehelper.SuggestNextWordDAO;
import com.example.android.softkeyboard.sqlitehelper.WordDAO;

@SuppressLint("NewApi")
public class SettingVNI extends Activity implements OnClickListener {
	private static final int SETUP = 0;

	private Context context;
	
	private ListView lvStylesOfKeyboard;
	private CheckBox cbPlaySound;
	private CheckBox cbVibration;
	private CheckBox cbMute;
	private CheckBox cbPredict;
	private CheckBox cbAutoStudying;
	private CheckBox cbCharacterPreview;
	private CheckBox cbAutoSwitchENVI;
	private CheckBox cbMethodAutomatic;
	private CheckBox cbMethodTelex;
	private CheckBox cbMethodVni;
	private CheckBox cbNumberRow;
	private CheckBox cbVietnameseCharacter;
	private Button btnClearUserData;
	private TextView tvAutoSwitchENVI;
	private TextView tvAutoDetectTelexVNI;
	private TextView tvTelexOnly;
	private TextView tvVniOnly;
	
	private WordDAO wordDAO = null;
	private SuggestNextWordDAO suggestDAO = null;
	private List<String> styleArray;
	private int currentStyle;
	private InputMethodManager myImm;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting_main);
		context = this;
		myImm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
		try {
            wordDAO = new WordDAO(getApplicationContext());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		try {
            suggestDAO = new SuggestNextWordDAO(getApplicationContext());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		/*Add styles for key board interface*/
		styleArray = new ArrayList<String>();
		styleArray.add("Sky Blue");
		styleArray.add("Slate Gray");
		styleArray.add("Pink Heart");
		styleArray.add("Blue Violet");
		styleArray.add("Medium Purple");
		styleArray.add("White and Black");
		
		lvStylesOfKeyboard = (ListView) findViewById(R.id.lv_style_keyboard);

		cbMethodAutomatic = (CheckBox) findViewById(R.id.cb_method_automatic);
		cbMethodTelex = (CheckBox) findViewById(R.id.cb_method_telex);
		cbMethodVni = (CheckBox) findViewById(R.id.cb_method_vni);
		cbNumberRow = (CheckBox) findViewById(R.id.cb_number_row);
		cbVietnameseCharacter = (CheckBox) findViewById(R.id.cb_vietnamese_character);
		cbPlaySound = (CheckBox) findViewById(R.id.cb_play_sound);
		cbVibration = (CheckBox) findViewById(R.id.cb_vibration);
		cbMute = (CheckBox) findViewById(R.id.cb_mute);
		cbPredict = (CheckBox) findViewById(R.id.cb_predict);
		cbAutoStudying = (CheckBox) findViewById(R.id.cb_auto_studying);
		cbCharacterPreview = (CheckBox) findViewById(R.id.cb_character_preview);
		cbAutoSwitchENVI = (CheckBox) findViewById(R.id.cb_auto_switch_envi);
		
		btnClearUserData = (Button) findViewById(R.id.btn_clear_user_data);
		
		tvAutoSwitchENVI = (TextView) findViewById(R.id.tv_auto_switch_en_vi);
		tvAutoDetectTelexVNI = (TextView) findViewById(R.id.tv_method_automatic);
		tvTelexOnly = (TextView) findViewById(R.id.tv_method_telex);
		tvVniOnly = (TextView) findViewById(R.id.tv_method_vni);

		initInterface();

		cbMethodAutomatic.setOnClickListener(this);
		cbMethodTelex.setOnClickListener(this);
		cbMethodVni.setOnClickListener(this);
		cbNumberRow.setOnClickListener(this);
		cbVietnameseCharacter.setOnClickListener(this);
		cbPredict.setOnClickListener(this);
		cbPlaySound.setOnClickListener(this);
		cbVibration.setOnClickListener(this);
		cbMute.setOnClickListener(this);
		cbAutoStudying.setOnClickListener(this);
		cbCharacterPreview.setOnClickListener(this);
		cbAutoSwitchENVI.setOnClickListener(this);
		btnClearUserData.setOnClickListener(this);
		
		final SharedPreferences sp = PreferenceManager
			.getDefaultSharedPreferences(context);
		final SharedPreferences.Editor editor = sp.edit();
		
		StyleKeyboardAdapter styleAdapter = new StyleKeyboardAdapter(
				SettingVNI.this, R.layout.keyboard_style_item, styleArray);
		lvStylesOfKeyboard.setAdapter(styleAdapter);

		lvStylesOfKeyboard.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				editor.putInt("STYLE_KEYBOARD", arg2);
				editor.commit();
				finish();
			}
		});
	}

	private void initInterface() {
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(this);

		if (sp.getBoolean("PLAY_SOUND", true)) {
			cbPlaySound.setChecked(true);
		} else {
			cbPlaySound.setChecked(false);
		}

		if (sp.getBoolean("VIBRATION", true)) {
			cbVibration.setChecked(true);
		} else {
			cbVibration.setChecked(false);
		}

		if (sp.getBoolean("MUTE", false)) {
			cbMute.setChecked(true);
		} else {
			cbMute.setChecked(false);
		}
		
		if (sp.getBoolean("PREDICT_TEXT", true)) {
			cbPredict.setChecked(true);
		} else {
			cbPredict.setChecked(false);
		}

		if (sp.getBoolean("AUTO_STUDYING", true)) {
			cbAutoStudying.setChecked(true);
		} else {
			cbAutoStudying.setChecked(false);
		}
		
		if (sp.getBoolean("CHARACTER_PREVIEW", false)) {
			cbCharacterPreview.setChecked(true);
		} else {
			cbCharacterPreview.setChecked(false);
		}
		
		if (sp.getInt("TYPING_LANGUAGE", 0) == 0) {
			cbNumberRow.setChecked(true);
		} else if (sp.getInt("TYPING_LANGUAGE", 0) == 2) {
			cbNumberRow.setChecked(false);
			cbVietnameseCharacter.setChecked(true);
		} else {
			cbNumberRow.setChecked(false);
			cbVietnameseCharacter.setChecked(false);
		}
		
		if(!cbVietnameseCharacter.isChecked()) {
			if (sp.getInt("TELEX_VNI",0) == 1) {
				cbMethodVni.setChecked(true);
			} else if (sp.getInt("TELEX_VNI",0) == 2) {
				cbMethodTelex.setChecked(false);
			} else {
				cbMethodAutomatic.setChecked(true);
			}
			if(!cbNumberRow.isChecked()){
				cbMethodTelex.setChecked(true);
				cbMethodVni.setChecked(false);
				cbMethodAutomatic.setChecked(false);
				cbMethodTelex.setEnabled(false);
				tvTelexOnly.setEnabled(false);
				cbMethodVni.setEnabled(false);
				tvVniOnly.setEnabled(false);
				cbMethodAutomatic.setEnabled(false);
				tvAutoDetectTelexVNI.setEnabled(false);
			}
			cbAutoSwitchENVI.setEnabled(true);
			tvAutoSwitchENVI.setEnabled(true);
			if(cbPredict.isChecked()) {
				cbAutoSwitchENVI.setEnabled(true);
				tvAutoSwitchENVI.setEnabled(true);
				if (sp.getBoolean("AUTO_SWITCH_ENVI", true)) {
					cbAutoSwitchENVI.setChecked(true);
				} else {
					cbAutoSwitchENVI.setChecked(false);
				}
			} else {
				cbAutoSwitchENVI.setChecked(false);
				cbAutoSwitchENVI.setEnabled(false);
				tvAutoSwitchENVI.setEnabled(false);
				sp.edit().putBoolean("AUTO_SWITCH_ENVI", false).commit();
			}
		} else {
			cbAutoSwitchENVI.setChecked(false);
			cbMethodVni.setChecked(false);
			cbMethodTelex.setChecked(false);
			cbMethodAutomatic.setChecked(false);
			cbMethodVni.setEnabled(false);
			tvVniOnly.setEnabled(false);
			cbMethodTelex.setEnabled(false);
			tvTelexOnly.setEnabled(false);
			cbMethodAutomatic.setEnabled(false);
			tvAutoDetectTelexVNI.setEnabled(false);
			cbAutoSwitchENVI.setEnabled(false);
			tvAutoSwitchENVI.setEnabled(false);
		}
		
		if (sp.getBoolean("FIRST_TIME", true) && !ImeUtils.isThisImeCurrent(this, myImm)){
			Intent introIntent =  new Intent(this, IntroActivity.class);
			startActivityForResult(introIntent, SETUP);
		}
		
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		if(ImeUtils.isThisImeCurrent(this, myImm)){
			setFirstTimePreference(this);
		}
		super.onResume();
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(getApplicationContext());
		SharedPreferences.Editor editor = sp.edit();
		switch (v.getId()) {
		case R.id.cb_predict:
			if (cbPredict.isChecked()) {
				editor.putBoolean("PREDICT_TEXT", true);
				tvAutoSwitchENVI.setEnabled(true);
				cbAutoSwitchENVI.setEnabled(true);
			} else {
				editor.putBoolean("PREDICT_TEXT", false);
				tvAutoSwitchENVI.setEnabled(false);
				cbAutoSwitchENVI.setEnabled(false);
				cbAutoSwitchENVI.setChecked(false);
				editor.putBoolean("AUTO_SWITCH_ENVI", false);
			}
			break;
		case R.id.cb_play_sound:
			if (cbPlaySound.isChecked()) {
				cbMute.setChecked(false);
				editor.putBoolean("MUTE", false);
				editor.putBoolean("PLAY_SOUND", true);
			} else {
				editor.putBoolean("PLAY_SOUND", false);
			}
			break;
		case R.id.cb_vibration:
			if (cbVibration.isChecked()) {
				cbMute.setChecked(false);
				editor.putBoolean("MUTE", false);
				editor.putBoolean("VIBRATION", true);
			} else {
				editor.putBoolean("VIBRATION", false);
			}
			break;
		case R.id.cb_mute:
			if (cbMute.isChecked()) {
				cbPlaySound.setChecked(false);
				cbVibration.setChecked(false);

				editor.putBoolean("PLAY_SOUND", false);
				editor.putBoolean("VIBRATION", false);
				editor.putBoolean("MUTE", true);
			} else {
				editor.putBoolean("MUTE", false);
			}
			break;
		case R.id.cb_auto_studying:
			if (cbAutoStudying.isChecked()) {
				editor.putBoolean("AUTO_STUDYING", true);
			} else {
				editor.putBoolean("AUTO_STUDYING", false);
			}
			break;
		case R.id.cb_character_preview:
			if (cbCharacterPreview.isChecked()) {
				editor.putBoolean("CHARACTER_PREVIEW", true);
			} else {
				editor.putBoolean("CHARACTER_PREVIEW", false);
			}
			break;
		case R.id.cb_auto_switch_envi:
			if (cbAutoSwitchENVI.isChecked()) {
				editor.putBoolean("AUTO_SWITCH_ENVI", true);
			} else {
				editor.putBoolean("AUTO_SWITCH_ENVI", false);
			}
			break;
		case R.id.cb_method_automatic:
			if (cbMethodAutomatic.isChecked()){
				cbMethodTelex.setChecked(false);
				cbMethodVni.setChecked(false);
				editor.putInt("TELEX_VNI", 0);
			} else {
				if(!cbMethodTelex.isChecked() && !cbMethodVni.isChecked()) {
					cbMethodAutomatic.setChecked(true);
				}	
			}
		break;
		case R.id.cb_method_telex:
			if (cbMethodTelex.isChecked()){
				cbMethodAutomatic.setChecked(false);
				cbMethodVni.setChecked(false);
				editor.putInt("TELEX_VNI", 2);
			} else {
				if(!cbMethodAutomatic.isChecked() && !cbMethodVni.isChecked()) {
					cbMethodTelex.setChecked(true);
				}
			}
		break;
		case R.id.cb_method_vni:
			if (cbMethodVni.isChecked()){
				cbMethodTelex.setChecked(false);
				cbMethodAutomatic.setChecked(false);
				editor.putInt("TELEX_VNI", 1);
			} else {
				if(!cbMethodAutomatic.isChecked() && !cbMethodTelex.isChecked()) {
					cbMethodVni.setChecked(true);
				}
			}
		break;
		case R.id.cb_number_row:
			if (cbNumberRow.isChecked()) {
				cbVietnameseCharacter.setChecked(false);
				cbMethodAutomatic.setEnabled(true);
				tvAutoDetectTelexVNI.setEnabled(true);
				
				cbMethodTelex.setEnabled(true);
				tvTelexOnly.setEnabled(true);
				cbMethodVni.setEnabled(true);
				tvVniOnly.setEnabled(true);
				
				if (!cbMethodAutomatic.isChecked() && !cbMethodTelex.isChecked() 
						&& !cbMethodVni.isChecked()) {
					cbMethodAutomatic.setChecked(true);
					editor.putInt("TELEX_VNI", 0);
				}
				editor.putInt("TYPING_LANGUAGE", 0);
				
				if(cbPredict.isChecked()) {
					cbAutoSwitchENVI.setEnabled(true);
					tvAutoSwitchENVI.setEnabled(true);
				} else {
					cbAutoSwitchENVI.setChecked(false);
					cbAutoSwitchENVI.setEnabled(false);
					tvAutoSwitchENVI.setEnabled(false);
					sp.edit().putBoolean("AUTO_SWITCH_ENVI", false);
				}
			} else {
				if(cbVietnameseCharacter.isChecked()) {
					editor.putInt("TYPING_LANGUAGE", 2);
					cbMethodAutomatic.setChecked(false);
					cbMethodTelex.setChecked(false);
					cbMethodVni.setChecked(false);
					cbAutoSwitchENVI.setChecked(false);
					editor.putBoolean("AUTO_SWITCH_ENVI", false);
					cbAutoSwitchENVI.setEnabled(false);
					tvAutoSwitchENVI.setEnabled(false);
				} else {
					editor.putInt("TELEX_VNI", 2);
					editor.putInt("TYPING_LANGUAGE", 1);
					cbMethodAutomatic.setChecked(false);
					cbMethodTelex.setChecked(true);
					cbMethodVni.setChecked(false);
					cbMethodAutomatic.setEnabled(false);
					tvAutoDetectTelexVNI.setEnabled(false);
					
					cbMethodTelex.setEnabled(false);
					tvTelexOnly.setEnabled(false);
					cbMethodVni.setEnabled(false);
					tvVniOnly.setEnabled(false);
					if(cbPredict.isChecked()) {
						cbAutoSwitchENVI.setEnabled(true);
						tvAutoSwitchENVI.setEnabled(true);
					}
				}
			}
		break;
		case R.id.cb_vietnamese_character:
			if (cbVietnameseCharacter.isChecked()) {
				cbMethodAutomatic.setChecked(false);
				cbMethodTelex.setChecked(false);
				cbMethodVni.setChecked(false);
				editor.putInt("TYPING_LANGUAGE", 2);
				cbNumberRow.setChecked(false);
				cbMethodAutomatic.setEnabled(false);
				tvAutoDetectTelexVNI.setEnabled(false);

				cbMethodTelex.setEnabled(false);
				tvTelexOnly.setEnabled(false);
				cbMethodVni.setEnabled(false);
				tvVniOnly.setEnabled(false);
				cbAutoSwitchENVI.setChecked(false);
				editor.putBoolean("AUTO_SWITCH_ENVI", false);
				cbAutoSwitchENVI.setEnabled(false);
				tvAutoSwitchENVI.setEnabled(false);
			} else {
				cbMethodAutomatic.setEnabled(true);
				tvAutoDetectTelexVNI.setEnabled(true);

				cbMethodTelex.setEnabled(true);
				tvTelexOnly.setEnabled(true);
				cbMethodVni.setEnabled(true);
				tvVniOnly.setEnabled(true);
				cbNumberRow.setChecked(true);
				cbMethodAutomatic.setChecked(true);
				editor.putInt("TYPING_LANGUAGE", 0);
				editor.putInt("TELEX_VNI", 0);
				
				if(cbPredict.isChecked()) {
					cbAutoSwitchENVI.setEnabled(true);
					tvAutoSwitchENVI.setEnabled(true);
				}
			}
		break;
		case R.id.btn_clear_user_data:
			showDialog();
			break;
		default:
			break;
		}
		editor.commit();
	}

	private void showDialog() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(
				SettingVNI.this);

		// Setting Dialog Title
		alertDialog.setTitle("Confirm Delete...");

		// Setting Dialog Message
		alertDialog.setMessage("Are you sure you want delete user data?");

		// Setting Positive "Yes" Button
		alertDialog.setPositiveButton("YES",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						wordDAO.reset();
						suggestDAO.reset();
					}
				});

		// Setting Negative "NO" Button
		alertDialog.setNegativeButton("NO",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {

					}
				});

		// Showing Alert Message
		alertDialog.show();
	}
	
	/**
	 * Get orientation of display
	 */
	@SuppressWarnings("deprecation")
	public int getScreenOrientation()
	{
	    Display getOrient = getWindowManager().getDefaultDisplay();
	    int orientation = Configuration.ORIENTATION_UNDEFINED;
	    if(getOrient.getWidth()==getOrient.getHeight()){
	        orientation = Configuration.ORIENTATION_SQUARE;
	    } else{ 
	        if(getOrient.getWidth() < getOrient.getHeight()){
	            orientation = Configuration.ORIENTATION_PORTRAIT;
	        }else { 
	             orientation = Configuration.ORIENTATION_LANDSCAPE;
	        }
	    }
	    return orientation;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == SETUP && resultCode == RESULT_CANCELED){
			finish();
		}
	}	
	
	private void setFirstTimePreference(Context context){
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);		
		SharedPreferences.Editor editor = sp.edit();
		editor.putBoolean("FIRST_TIME", false);
		editor.commit();
	}
}
