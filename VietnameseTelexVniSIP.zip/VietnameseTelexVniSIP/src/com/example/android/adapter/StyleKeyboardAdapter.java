package com.example.android.adapter;

import java.util.List;

import com.example.android.softkeyboard.R;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class StyleKeyboardAdapter extends ArrayAdapter<String>{

	private Context mContext;
	private List<String> styleList;
	private int layoutResourceId;
	private int currentStyle = 1;
	
	public StyleKeyboardAdapter(Context context, int resource, List<String> styleList) {
		super(context, resource , styleList);
		// TODO Auto-generated constructor stub
		this.layoutResourceId = resource;
		this.mContext = context;
		this.styleList = styleList;
		SharedPreferences sp = PreferenceManager
				.getDefaultSharedPreferences(context);
		currentStyle = sp.getInt("STYLE_KEYBOARD", 1);
		
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		 if(convertView==null){
	         // inflate the layout
	         LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
	         convertView = inflater.inflate(layoutResourceId, parent, false);
	     }
	     // object item based on the position
		 //int layOutID = styleList.get(position);
	     //ImageView imageViewItem = (ImageView) convertView.findViewById(R.id.img_keyboard_style_item);
	     //imageViewItem.setBackgroundResource(layOutID);
		 String strStyle = styleList.get(position);
		 if(strStyle != null) {
			 TextView tvStyleKeyboard = (TextView) convertView.findViewById(R.id.tv_keyboard_style);
			 if(tvStyleKeyboard != null) {
				 if(currentStyle == position) {
					 tvStyleKeyboard.setText(strStyle);
					 tvStyleKeyboard.setTextColor(Color.GREEN);
				 } else {
					 tvStyleKeyboard.setText(strStyle);
					 tvStyleKeyboard.setTextColor(Color.WHITE);
				 }
				 //tvStyleKeyboard.setTextSize(50);
			 }
		 }
	     return convertView;
	}

	
}
